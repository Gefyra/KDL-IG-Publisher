# ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.typeCodes - Kontext: Archivierung, inkl. eVV - v2026.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.typeCodes - Kontext: Archivierung, inkl. eVV**

## ConceptMap: ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.typeCodes - Kontext: Archivierung, inkl. eVV 

| | |
| :--- | :--- |
| *Official URL*:http://dvmd.de/fhir/ConceptMap/kdl-ihe-typecode | *Version*:2026.0.0 |
| Active as of 2026-01-01 | *Computable Name*:ConceptMapKdlIheTypecode |
| **Copyright/Legal**: 2026 DVMD e.V. | |

 
Diese Ressource dient als Grundlage für die Zuordnung von KDL-Codes zu IHE-XDS DocumentEntry.typeCodes (gemäß Spezifikation von IHE Deutschland e.V., siehe http://www.ihe-d.de/projekte/xds-value-sets-fuer-deutschland/). Grundlage ist der ANWENDUNGSFALL: DIGITALE ARCHIVIERUNG, inkl. aktuelle Anforderungen des Anhangs zur Anlage 1 der eVV. Das Reviewergebnis - zu diesem Mappingkonzept - von der IHE-AG IHE-XDS ValueSets aus 2023 wurde berücksichtigt. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "kdl-ihe-typecode",
  "url" : "http://dvmd.de/fhir/ConceptMap/kdl-ihe-typecode",
  "version" : "2026.0.0",
  "name" : "ConceptMapKdlIheTypecode",
  "title" : "ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.typeCodes - Kontext: Archivierung, inkl. eVV",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-01-01",
  "publisher" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
  "contact" : [
    {
      "name" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.dvmd.de"
        },
        {
          "system" : "email",
          "value" : "dvmd@dvmd.de"
        }
      ]
    }
  ],
  "description" : "Diese Ressource dient als Grundlage für die Zuordnung von KDL-Codes zu IHE-XDS DocumentEntry.typeCodes (gemäß Spezifikation von IHE Deutschland e.V., siehe http://www.ihe-d.de/projekte/xds-value-sets-fuer-deutschland/). Grundlage ist der ANWENDUNGSFALL: DIGITALE ARCHIVIERUNG, inkl. aktuelle Anforderungen des Anhangs zur Anlage 1 der eVV. Das Reviewergebnis - zu diesem Mappingkonzept - von der IHE-AG IHE-XDS ValueSets aus 2023 wurde berücksichtigt.",
  "copyright" : "2026 DVMD e.V.",
  "sourceUri" : "http://dvmd.de/fhir/ValueSet/kdl",
  "targetUri" : "http://ihe-d.de/ValueSets/IHEXDStypeCode",
  "group" : [
    {
      "source" : "http://dvmd.de/fhir/CodeSystem/kdl",
      "target" : "http://ihe-d.de/CodeSystems/IHEXDStypeCode",
      "element" : [
        {
          "code" : "AD010101",
          "display" : "Ärztliche Stellungnahme",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010102",
          "display" : "Durchgangsarztbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010103",
          "display" : "Entlassungsbericht intern",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010104",
          "display" : "Entlassungsbericht extern",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010105",
          "display" : "Reha-Bericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010106",
          "display" : "Verlegungsbericht intern",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010107",
          "display" : "Verlegungsbericht extern",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010108",
          "display" : "Vorläufiger Arztbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010109",
          "display" : "Ärztlicher Befundbericht",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010110",
          "display" : "Ärztlicher Verlaufsbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010111",
          "display" : "Ambulanzbrief",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010112",
          "display" : "Kurzarztbrief",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010113",
          "display" : "Nachschaubericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010114",
          "display" : "Interventionsbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010115",
          "display" : "Entlassungsbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010116",
          "display" : "Verlegungsbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD010199",
          "display" : "Sonstiger Arztbericht",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020101",
          "display" : "Arbeitsunfähigkeitsbescheinigung",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020102",
          "display" : "Beurlaubung",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020103",
          "display" : "Todesbescheinigung",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020104",
          "display" : "Ärztliche Bescheinigung",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020105",
          "display" : "Notfall-/Vertretungsschein",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020106",
          "display" : "Wiedereingliederungsplan",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020107",
          "display" : "Aufenthaltsbescheinigung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020108",
          "display" : "Geburtsanzeige",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020199",
          "display" : "Sonstige Bescheinigung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020201",
          "display" : "Anatomische Skizze",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020202",
          "display" : "Befundbogen",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020203",
          "display" : "Bericht Gesundheitsuntersuchung",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020204",
          "display" : "Krebsfrüherkennung",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020205",
          "display" : "Messblatt",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020206",
          "display" : "Belastungserprobung",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020207",
          "display" : "Ärztlicher Fragebogen",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020208",
          "display" : "Befund extern",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD020299",
          "display" : "Sonstige ärztliche Befunderhebung",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060101",
          "display" : "Konsilanforderung",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060102",
          "display" : "Konsilanmeldung",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060103",
          "display" : "Konsilbericht intern",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060104",
          "display" : "Konsilbericht extern",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060105",
          "display" : "Visitenprotokoll",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060106",
          "display" : "Tumorkonferenzprotokoll",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060107",
          "display" : "Teambesprechungsprotokoll",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060108",
          "display" : "Anordnung/Verordnung",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060109",
          "display" : "Verordnung",
          "target" : [
            {
              "code" : "VERO",
              "display" : "Verordnungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060110",
          "display" : "Konsilbericht",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AD060199",
          "display" : "Sonstige Fallbesprechung",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010101",
          "display" : "Übersicht abrechnungsrelevanter Diagnosen / Prozeduren",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010102",
          "display" : "G-AEP Kriterien",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010103",
          "display" : "Kostenübernahmeverlängerung",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010104",
          "display" : "Schriftverkehr MD Kasse",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010105",
          "display" : "Abrechnungsschein",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010106",
          "display" : "Rechnung ambulante/stationäre Behandlung",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010107",
          "display" : "MD Prüfauftrag",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010108",
          "display" : "MD Gutachten",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010109",
          "display" : "Begründete Unterlagen Leistungskodierung",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010110",
          "display" : "Heil- und Kostenplan",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010111",
          "display" : "Kostenvoranschlag",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010199",
          "display" : "Sonstige Abrechnungsdokumentation",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010201",
          "display" : "Antrag auf Rehabilitation",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010202",
          "display" : "Antrag auf Betreuung",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010203",
          "display" : "Antrag auf gesetzliche Unterbringung",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010204",
          "display" : "Verlängerungsantrag",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010205",
          "display" : "Antrag auf Psychotherapie",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010206",
          "display" : "Antrag auf Pflegeeinstufung",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010207",
          "display" : "Kostenübernahmeantrag",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010208",
          "display" : "Antrag auf Leistungen der Pflegeversicherung",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010209",
          "display" : "Antrag auf Kurzzeitpflege",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010210",
          "display" : "Antrag auf Fixierung/Isolierung beim Amtsgericht",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010211",
          "display" : "Antrag abrechnungsrelevante OPS-Kodes",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010299",
          "display" : "Sonstiger Antrag",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010301",
          "display" : "Anästhesieaufklärungsbogen",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010302",
          "display" : "Diagnostischer Aufklärungsbogen",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010303",
          "display" : "Operationsaufklärungsbogen",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010304",
          "display" : "Aufklärungsbogen Therapie",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM010399",
          "display" : "Sonstiger Aufklärungsbogen",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030101",
          "display" : "Aktenlaufzettel",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030102",
          "display" : "Checkliste Entlassung",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030103",
          "display" : "Entlassungsplan",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030104",
          "display" : "Patientenlaufzettel",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM030199",
          "display" : "Sonstige Checkliste Administration",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050101",
          "display" : "Datenschutzerklärung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050102",
          "display" : "Einverständniserklärung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050103",
          "display" : "Erklärung Nichtansprechbarkeit Patienten",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050104",
          "display" : "Einverständniserklärung Abrechnung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050105",
          "display" : "Einverständniserklärung Behandlung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050106",
          "display" : "Einwilligung und Datenschutzerklärung Entlassungsmanagement",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050107",
          "display" : "Schweigepflichtentbindung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050108",
          "display" : "Entlassung gegen ärztlichen Rat",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050109",
          "display" : "Aufforderung zur Herausgabe der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050110",
          "display" : "Aufforderung zur Löschung der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050111",
          "display" : "Aufforderung zur Berichtigung der medizinischen Dokumentation",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM050199",
          "display" : "Sonstige Einwilligung/Erklärung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160101",
          "display" : "Blutgruppenausweis",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160102",
          "display" : "Impfausweis",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160103",
          "display" : "Vorsorgevollmacht",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160104",
          "display" : "Patientenverfügung",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160105",
          "display" : "Wertgegenständeverwaltung",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160106",
          "display" : "Allergiepass",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160107",
          "display" : "Herzschrittmacherausweis",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160108",
          "display" : "Nachlassprotokoll",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160109",
          "display" : "Mutterpass (Kopie)",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160110",
          "display" : "Ausweiskopie",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160111",
          "display" : "Implantat-Ausweis",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160112",
          "display" : "Betreuerausweis",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160113",
          "display" : "Patientenbild",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160114",
          "display" : "Anästhesieausweis",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160199",
          "display" : "Sonstiges patienteneigenes Dokument",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160201",
          "display" : "Belehrung",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160202",
          "display" : "Informationsblatt",
          "target" : [
            {
              "code" : "PATI",
              "display" : "Patienteninformationen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160203",
          "display" : "Informationsblatt Entlassungsmanagement",
          "target" : [
            {
              "code" : "PATI",
              "display" : "Patienteninformationen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160299",
          "display" : "Sonstiges Patienteninformationsblatt",
          "target" : [
            {
              "code" : "PATI",
              "display" : "Patienteninformationen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160301",
          "display" : "Heil- / Hilfsmittelverordnung",
          "target" : [
            {
              "code" : "VERO",
              "display" : "Verordnungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160302",
          "display" : "Krankentransportschein",
          "target" : [
            {
              "code" : "VERO",
              "display" : "Verordnungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160303",
          "display" : "Verordnung häusliche Krankenpflege",
          "target" : [
            {
              "code" : "VERO",
              "display" : "Verordnungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM160399",
          "display" : "Sonstige poststationäre Verordnung",
          "target" : [
            {
              "code" : "VERO",
              "display" : "Verordnungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170101",
          "display" : "Dokumentationsbogen Meldepflicht",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170102",
          "display" : "Hygienestandard",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170103",
          "display" : "Patientenfragebogen",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170104",
          "display" : "Pflegestandard",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170105",
          "display" : "Qualitätssicherungsbogen",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM170199",
          "display" : "Sonstiges Qualitätssicherungsdokument",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190101",
          "display" : "Anforderung Unterlagen",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190102",
          "display" : "Schriftverkehr Amtsgericht",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190103",
          "display" : "Schriftverkehr MD Arzt",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190104",
          "display" : "Schriftverkehr Krankenkasse",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190105",
          "display" : "Schriftverkehr Deutsche Rentenversicherung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190106",
          "display" : "Sendebericht",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190107",
          "display" : "Empfangsbestätigung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190108",
          "display" : "Handschriftliche Notiz",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190109",
          "display" : "Lieferschein",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190110",
          "display" : "Schriftverkehr Amt/Gericht/Anwalt",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190111",
          "display" : "Schriftverkehr Strafverfolgung und Schadensersatz",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190112",
          "display" : "Anforderung Unterlagen MD",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190113",
          "display" : "Widerspruchsbegründung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190114",
          "display" : "Schriftverkehr Unfallversicherungsträger und Leistungserbringer",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190199",
          "display" : "Sonstiger Schriftverkehr",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190201",
          "display" : "Beratungsbogen Sozialer Dienst",
          "target" : [
            {
              "code" : "SOZI",
              "display" : "Sozialdienstdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190202",
          "display" : "Soziotherapeutischer Betreuungsplan",
          "target" : [
            {
              "code" : "SOZI",
              "display" : "Sozialdienstdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190203",
          "display" : "Einschätzung Sozialdienst",
          "target" : [
            {
              "code" : "SOZI",
              "display" : "Sozialdienstdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190204",
          "display" : "Abschlussbericht Sozialdienst",
          "target" : [
            {
              "code" : "SOZI",
              "display" : "Sozialdienstdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM190299",
          "display" : "Sonstiges Dokument Sozialdienst",
          "target" : [
            {
              "code" : "SOZI",
              "display" : "Sozialdienstdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220101",
          "display" : "Behandlungsvertrag",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220102",
          "display" : "Wahlleistungsvertrag",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220103",
          "display" : "Heimvertrag",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220104",
          "display" : "Angaben zur Vergütung von Mitarbeitenden",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AM220199",
          "display" : "Sonstiger Vertrag",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010101",
          "display" : "Anamnesebogen",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010102",
          "display" : "Anmeldung Aufnahme",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010103",
          "display" : "Aufnahmebogen",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010104",
          "display" : "Checkliste Aufnahme",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010105",
          "display" : "Stammblatt",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU010199",
          "display" : "Sonstige Aufnahmedokumentation",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050101",
          "display" : "Verordnung von Krankenhausbehandlung",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050102",
          "display" : "Überweisungsschein",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050103",
          "display" : "Überweisungsschein Entlassung",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050104",
          "display" : "Verlegungsschein Intern",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU050199",
          "display" : "Sonstiges Einweisungs-/Überweisungsdokument",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190101",
          "display" : "Einsatzprotokoll",
          "target" : [
            {
              "code" : "RETT",
              "display" : "Rettungsdienstliche Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190102",
          "display" : "Notaufnahmebericht",
          "target" : [
            {
              "code" : "RETT",
              "display" : "Rettungsdienstliche Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190103",
          "display" : "Notaufnahmebogen",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190104",
          "display" : "Notfalldatensatz",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190105",
          "display" : "ISAR Screening",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "AU190199",
          "display" : "Sonstige Dokumentation Rettungsstelle",
          "target" : [
            {
              "code" : "RETT",
              "display" : "Rettungsdienstliche Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020101",
          "display" : "Anforderung bildgebende Diagnostik",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020102",
          "display" : "Angiographiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020103",
          "display" : "CT-Befund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020104",
          "display" : "Echokardiographiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020105",
          "display" : "Endoskopiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020106",
          "display" : "Herzkatheterprotokoll",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020107",
          "display" : "MRT-Befund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020108",
          "display" : "OCT-Befund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020109",
          "display" : "PET-Befund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020110",
          "display" : "Röntgenbefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020111",
          "display" : "Sonographiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020112",
          "display" : "SPECT-Befund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020113",
          "display" : "Szintigraphiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020114",
          "display" : "Mammographiebefund",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020115",
          "display" : "Checkliste bildgebende Diagnostik",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020116",
          "display" : "Zugangscode Bildportal",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG020199",
          "display" : "Sonstige Dokumentation bildgebende Diagnostik",
          "target" : [
            {
              "code" : "BILD",
              "display" : "Ergebnisse bildgebender Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060101",
          "display" : "Anforderung Funktionsdiagnostik",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060102",
          "display" : "Audiometriebefund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060103",
          "display" : "Befund evozierter Potentiale",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060104",
          "display" : "Blutdruckprotokoll",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060105",
          "display" : "CTG-Ausdruck",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060106",
          "display" : "Dokumentationsbogen Feststellung Hirntod",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060107",
          "display" : "Dokumentationsbogen Herzschrittmacherkontrolle",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060108",
          "display" : "Dokumentationsbogen Lungenfunktionsprüfung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060109",
          "display" : "EEG-Auswertung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060110",
          "display" : "EMG-Befund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060111",
          "display" : "EKG-Auswertung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060112",
          "display" : "Manometriebefund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060113",
          "display" : "Messungsprotokoll Augeninnendruck",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060114",
          "display" : "Neurographiebefund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060115",
          "display" : "Rhinometriebefund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060116",
          "display" : "Schlaflabordokumentationsbogen",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060117",
          "display" : "Schluckuntersuchung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060118",
          "display" : "Checkliste Funktionsdiagnostik",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060119",
          "display" : "Ergometriebefund",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060120",
          "display" : "Kipptischuntersuchung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060121",
          "display" : "Augenuntersuchung",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060122",
          "display" : "Dokumentationsbogen ICD-Kontrolle",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060123",
          "display" : "Zystometrie",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060124",
          "display" : "Uroflowmetrie",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060199",
          "display" : "Sonstige Dokumentation Funktionsdiagnostik",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060201",
          "display" : "Schellong Test",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060202",
          "display" : "H2 Atemtest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060203",
          "display" : "Allergietest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060204",
          "display" : "Zahlenverbindungstest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060205",
          "display" : "6-Minuten-Gehtest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060209",
          "display" : "Sonstige Funktionstests",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "DG060299",
          "display" : "Sonstiger Funktionstest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED010199",
          "display" : "Sonstige Audiodokumentation",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020101",
          "display" : "Fotodokumentation Operation",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020102",
          "display" : "Fotodokumentation Dermatologie",
          "target" : [
            {
              "code" : "FOTO",
              "display" : "Fotodokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020103",
          "display" : "Fotodokumentation Diagnostik",
          "target" : [
            {
              "code" : "FOTO",
              "display" : "Fotodokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020104",
          "display" : "Videodokumentation Operation",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED020199",
          "display" : "Foto-/Videodokumentation Sonstige",
          "target" : [
            {
              "code" : "FOTO",
              "display" : "Fotodokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110101",
          "display" : "Behandlungspfad",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110102",
          "display" : "Notfalldatenmanagement (NFDM)",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110103",
          "display" : "Medikationsplan elektronisch (eMP)",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110104",
          "display" : "eArztbrief",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110105",
          "display" : "eImpfpass",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110106",
          "display" : "eZahnärztliches Bonusheft",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110107",
          "display" : "eArbeitsunfähigkeitsbescheinigung",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110108",
          "display" : "eRezept",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110109",
          "display" : "Pflegebericht",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110110",
          "display" : "eDMP",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110111",
          "display" : "eMutterpass",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110112",
          "display" : "KH-Entlassbrief",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110113",
          "display" : "U-Heft Untersuchungen",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110114",
          "display" : "U-Heft Teilnahmekarte",
          "target" : [
            {
              "code" : "BESC",
              "display" : "Ärztliche Bescheinigungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110115",
          "display" : "U-Heft Elternnotiz",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110116",
          "display" : "Überleitungsbogen",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED110199",
          "display" : "Sonstige Dokumentation KIS",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190101",
          "display" : "E-Mail Befundauskunft",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190102",
          "display" : "E-Mail Juristische Beweissicherung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190103",
          "display" : "E-Mail Arztauskunft",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190104",
          "display" : "E-Mail Sonstige",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190105",
          "display" : "Fax Befundauskunft",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190106",
          "display" : "Fax Juristische Beweissicherung",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190107",
          "display" : "Fax Arztauskunft",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190108",
          "display" : "Fax Sonstige",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "ED190199",
          "display" : "Sonstiger elektronischer Schriftverkehr",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020101",
          "display" : "Blutgasanalyse",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020102",
          "display" : "Blutkulturenbefund",
          "target" : [
            {
              "code" : "MKRO",
              "display" : "Ergebnisse Mikrobiologie",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020103",
          "display" : "Herstellungs- und Prüfprotokoll von Blut und Blutprodukten",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020104",
          "display" : "Serologischer Befund",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB020199",
          "display" : "Sonstige Dokumentation Blut",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120101",
          "display" : "Glukosetoleranztestprotokoll",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120102",
          "display" : "Laborbefund extern",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120103",
          "display" : "Laborbefund intern",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120104",
          "display" : "Anforderung Labor",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120105",
          "display" : "Überweisungsschein Labor",
          "target" : [
            {
              "code" : "AUFN",
              "display" : "Einweisungs- und Aufnahmedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120106",
          "display" : "Hämatologisches Speziallabor",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120107",
          "display" : "Laborbefund",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB120199",
          "display" : "Sonstiger Laborbefund",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB130101",
          "display" : "Mikrobiologiebefund",
          "target" : [
            {
              "code" : "MKRO",
              "display" : "Ergebnisse Mikrobiologie",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB130102",
          "display" : "Urinbefund",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB220101",
          "display" : "Befund über positive Infektionsmarker",
          "target" : [
            {
              "code" : "IMMU",
              "display" : "Ergebnisse Immunologie",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "LB220102",
          "display" : "Virologiebefund",
          "target" : [
            {
              "code" : "VIRO",
              "display" : "Ergebnisse Virologie",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010101",
          "display" : "Intraoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010102",
          "display" : "Aufwachraumprotokoll",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010103",
          "display" : "Checkliste Anästhesie",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010104",
          "display" : "Präoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010105",
          "display" : "Postoperative Anästhesiedokumentation",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP010199",
          "display" : "Sonstige Anästhesiedokumentation",
          "target" : [
            {
              "code" : "ANAE",
              "display" : "Anästhesiedokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150101",
          "display" : "Chargendokumentation",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150102",
          "display" : "OP-Anmeldungsbogen",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150103",
          "display" : "OP-Bericht",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150104",
          "display" : "OP-Bilddokumentation",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150105",
          "display" : "OP-Checkliste",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150106",
          "display" : "OP-Protokoll",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150107",
          "display" : "Postoperative Verordnung",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150108",
          "display" : "OP-Zählprotokoll",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150109",
          "display" : "Dokumentation ambulantes Operieren",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP150199",
          "display" : "Sonstige OP-Dokumentation",
          "target" : [
            {
              "code" : "OPDK",
              "display" : "OP-Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200101",
          "display" : "Transplantationsprotokoll",
          "target" : [
            {
              "code" : "TRPL",
              "display" : "Transplantationsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200102",
          "display" : "Spenderdokument",
          "target" : [
            {
              "code" : "TRPL",
              "display" : "Transplantationsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "OP200199",
          "display" : "Sonstige Transplantationsdokumentation",
          "target" : [
            {
              "code" : "TRPL",
              "display" : "Transplantationsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT080101",
          "display" : "Histologieanforderung",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT080102",
          "display" : "Histologiebefund",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT130101",
          "display" : "Molekularpathologieanforderung",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT130102",
          "display" : "Molekularpathologiebefund",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT230199",
          "display" : "Sonstige pathologische Dokumentation",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT260101",
          "display" : "Zytologieanforderung",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "PT260102",
          "display" : "Zytologiebefund",
          "target" : [
            {
              "code" : "PATH",
              "display" : "Pathologiebefundberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070101",
          "display" : "Geburtenbericht",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070102",
          "display" : "Geburtenprotokoll",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070103",
          "display" : "Geburtenverlaufskurve",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070104",
          "display" : "Neugeborenenscreening",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070105",
          "display" : "Partogramm",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070106",
          "display" : "Wiegekarte",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070107",
          "display" : "Neugeborenendokumentationsbogen",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070108",
          "display" : "Säuglingskurve",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070109",
          "display" : "Geburtenbogen",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070110",
          "display" : "Perzentilkurve",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070111",
          "display" : "Entnahme Nabelschnurblut",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070112",
          "display" : "Datenblatt für den Pädiater",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070199",
          "display" : "Sonstige Geburtendokumentation",
          "target" : [
            {
              "code" : "GEBU",
              "display" : "Schwangerschafts- und Geburtsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070201",
          "display" : "Barthel Index",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070202",
          "display" : "Dem Tect",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070203",
          "display" : "ISAR Screening",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070204",
          "display" : "Sturzrisikoerfassungsbogen",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070205",
          "display" : "Geriatrische Depressionsskala",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070206",
          "display" : "Geriatrische Assessmentdokumentation",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070207",
          "display" : "Mobilitätstest nach Tinetti",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070208",
          "display" : "Timed Up and Go Test",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD070299",
          "display" : "Sonstiges geriatrisches Dokument",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110101",
          "display" : "Geriatrische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110102",
          "display" : "Intensivmedizinische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110103",
          "display" : "MRE/Nicht-MRE Komplexbehandlung",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110104",
          "display" : "Neurologische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110105",
          "display" : "Palliativmedizinische Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110106",
          "display" : "PKMS-Dokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110107",
          "display" : "Dokumentation COVID",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD110199",
          "display" : "Sonstige Komplexbehandlungsdokumentation",
          "target" : [
            {
              "code" : "KOMP",
              "display" : "Komplexbehandlungsbögen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130101",
          "display" : "Vertrag Maßregelvollzug",
          "target" : [
            {
              "code" : "VERT",
              "display" : "Verträge",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130102",
          "display" : "Antrag Maßregelvollzug",
          "target" : [
            {
              "code" : "ANTR",
              "display" : "Anträge und deren Bescheide",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130103",
          "display" : "Schriftverkehr Maßregelvollzug",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130104",
          "display" : "Einwilligung/Einverständniserklärung Maßregelvollzug",
          "target" : [
            {
              "code" : "EINW",
              "display" : "Einwilligungen/Aufklärungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD130199",
          "display" : "Sonstiges Maßregelvollzugdokument",
          "target" : [
            {
              "code" : "SCHR",
              "display" : "Schriftwechsel (administrativ)",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150101",
          "display" : "Follow up-Bogen",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150102",
          "display" : "Meldebogen Krebsregister",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150103",
          "display" : "Tumorkonferenzprotokoll",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150104",
          "display" : "Tumorlokalisationsbogen",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD150199",
          "display" : "Sonstiger onkologischer Dokumentationsbogen",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160101",
          "display" : "Patientenaufzeichnungen",
          "target" : [
            {
              "code" : "PATD",
              "display" : "Patienteneigene Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160102",
          "display" : "Testpsychologische Diagnostik",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160103",
          "display" : "Psychiatrisch-psychotherapeutische Therapieanordnung",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160104",
          "display" : "Psychiatrisch-psychotherapeutische Therapiedokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160105",
          "display" : "Psychiatrisch-psychotherapeutischer Verlaufsbogen",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160106",
          "display" : "Spezialtherapeutische Verlaufsdokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160107",
          "display" : "Therapieeinheiten Ärzte/Psychologen/Spezialtherapeuten",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160108",
          "display" : "1:1 Betreuung/Einzelbetreuung/Psychiatrische Intensivbehandlung",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160109",
          "display" : "Checkliste für die Unterbringung psychisch Kranker",
          "target" : [
            {
              "code" : "ADCH",
              "display" : "Administrative Checklisten",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160110",
          "display" : "Dokumentation Verhaltensanalyse",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160111",
          "display" : "Dokumentation Depression",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160112",
          "display" : "Dokumentation Stationsäquivalente Behandlung (StäB)",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SD160199",
          "display" : "Sonstiges psychiatrisch-psychotherapeutisches Dokument",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF060101",
          "display" : "Forschungsbericht",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF060199",
          "display" : "Sonstige Forschungsdokumentation",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190101",
          "display" : "CRF-Bogen",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190102",
          "display" : "Einwilligung Studie",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190103",
          "display" : "Protokoll Ein- und Ausschlusskriterien",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190104",
          "display" : "Prüfplan",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190105",
          "display" : "SOP-Bogen",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190106",
          "display" : "Studienbericht",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "SF190199",
          "display" : "Sonstige Studiendokumentation",
          "target" : [
            {
              "code" : "STUD",
              "display" : "Studiendokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020101",
          "display" : "Bestrahlungsplan",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020102",
          "display" : "Bestrahlungsprotokoll",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020103",
          "display" : "Bestrahlungsverordnung",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020104",
          "display" : "Radiojodtherapieprotokoll",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020105",
          "display" : "Therapieprotokoll mit Radionukliden",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH020199",
          "display" : "Sonstiges Bestrahlungstherapieprotokoll",
          "target" : [
            {
              "code" : "BSTR",
              "display" : "Bestrahlungsdokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060101",
          "display" : "Ergotherapieprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060102",
          "display" : "Logopädieprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060103",
          "display" : "Physiotherapieprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060104",
          "display" : "Anforderung Funktionstherapie",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060105",
          "display" : "Elektrokonvulsionstherapie",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060106",
          "display" : "Transkranielle Magnetstimulation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH060199",
          "display" : "Sonstiges Funktionstherapieprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130101",
          "display" : "Anforderung Medikation",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130102",
          "display" : "Arzneimitteladministration",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130103",
          "display" : "Chemotherapieprotokoll",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130104",
          "display" : "Hormontherapieprotokoll",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130105",
          "display" : "Medikamentenplan extern",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130106",
          "display" : "Medikamentenplan intern/extern (mit BTM)",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130107",
          "display" : "Medikationsplan",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130108",
          "display" : "Rezept",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130109",
          "display" : "Schmerztherapieprotokoll",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130110",
          "display" : "Prämedikationsprotokoll",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130111",
          "display" : "Lyse Dokument",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH130199",
          "display" : "Sonstiges Dokument medikamentöser Therapie",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160101",
          "display" : "Protokoll Ernährungsberatung",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160102",
          "display" : "Apotheke Patientenberatung",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH160199",
          "display" : "Sonstiges Protokoll Patientenschulung",
          "target" : [
            {
              "code" : "PATI",
              "display" : "Patienteninformationen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200101",
          "display" : "Anforderung Blutkonserven",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200102",
          "display" : "Blutspendeprotokoll",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200103",
          "display" : "Bluttransfusionsprotokoll",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200104",
          "display" : "Konservenbegleitschein",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH200199",
          "display" : "Sonstiges Transfusionsdokument",
          "target" : [
            {
              "code" : "TRFU",
              "display" : "Transfusionsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "TH230199",
          "display" : "Sonstige Therapiedokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999996",
          "display" : "Nachweise (Zusatz-) Entgelte",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999999",
          "display" : "Sonstige medizinische Dokumentation",
          "target" : [
            {
              "code" : "ABRE",
              "display" : "Abrechnungsdokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010101",
          "display" : "Dekubitusrisikoeinschätzung",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010102",
          "display" : "Mini Mental Status Test inkl. Uhrentest",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010103",
          "display" : "Schmerzerhebungsbogen",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010104",
          "display" : "Ernährungsscreening",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010105",
          "display" : "Aphasiescreening",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010106",
          "display" : "Glasgow Coma Scale",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010107",
          "display" : "NIH Stroke Scale",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010108",
          "display" : "IPSS (Internationaler Prostata Symptom Score)",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010109",
          "display" : "Sepsisdokumentation",
          "target" : [
            {
              "code" : "QUAL",
              "display" : "Qualitätssicherung",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010199",
          "display" : "Sonstiger Assessmentbogen",
          "target" : [
            {
              "code" : "FUNK",
              "display" : "Ergebnisse Funktionsdiagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010201",
          "display" : "Apotheke Entlassbericht",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010202",
          "display" : "Apotheke Betreuungsplan",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010203",
          "display" : "Arzneimittelinformation",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010204",
          "display" : "Apotheke Validierung",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010205",
          "display" : "Apotheke Visitenprotokoll",
          "target" : [
            {
              "code" : "FALL",
              "display" : "Fallbesprechungen",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010206",
          "display" : "AMTS-Prüfbericht",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010207",
          "display" : "Apotheke Interventionsbericht",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010208",
          "display" : "Arzneimittelabgabe",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL010299",
          "display" : "Sonstige Apothekendokumentation",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040101",
          "display" : "Diabetiker Kurve",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040102",
          "display" : "Insulinplan",
          "target" : [
            {
              "code" : "MEDI",
              "display" : "Medikamentöse Therapien",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040199",
          "display" : "Sonstige Diabetesdokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040201",
          "display" : "Dialyseanforderung",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040202",
          "display" : "Dialyseprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040299",
          "display" : "Sonstige Dialysedokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040301",
          "display" : "Ein- und Ausfuhrprotokoll",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040302",
          "display" : "Fixierungsprotokoll",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040303",
          "display" : "Isolierungsprotokoll",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040304",
          "display" : "Lagerungsplan",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040305",
          "display" : "Punktionsprotokoll",
          "target" : [
            {
              "code" : "BEFU",
              "display" : "Ergebnisse Diagnostik",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040306",
          "display" : "Punktionsprotokoll therapeutisch",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040307",
          "display" : "Reanimationsprotokoll",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040308",
          "display" : "Sondenplan",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040309",
          "display" : "Behandlungsplan",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040310",
          "display" : "Infektionsdokumentationsbogen",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040311",
          "display" : "Nosokomialdokumentation",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040312",
          "display" : "Stomadokumentation",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040313",
          "display" : "Katheterdokument",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040314",
          "display" : "Kardioversion",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL040399",
          "display" : "Sonstiger Durchführungsnachweis",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090101",
          "display" : "Beatmungsprotokoll",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090102",
          "display" : "Intensivkurve",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090103",
          "display" : "Intensivpflegebericht",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090104",
          "display" : "Monitoringausdruck",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090105",
          "display" : "Intensivdokumentationsbogen",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL090199",
          "display" : "Sonstiger Intensivdokumentationsbogen",
          "target" : [
            {
              "code" : "INTS",
              "display" : "Intensivmedizinische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160101",
          "display" : "Auszug aus den medizinischen Daten",
          "target" : [
            {
              "code" : "BERI",
              "display" : "Arztberichte",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160102",
          "display" : "Ernährungsplan",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160103",
          "display" : "Meldebogen Krebsregister",
          "target" : [
            {
              "code" : "ONKO",
              "display" : "Onkologische Dokumente",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160104",
          "display" : "Pflegeanamnesebogen",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160105",
          "display" : "Pflegebericht",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160106",
          "display" : "Pflegekurve",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160107",
          "display" : "Pflegeplanung",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160108",
          "display" : "Pflegeüberleitungsbogen",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160109",
          "display" : "Sturzprotokoll",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160110",
          "display" : "Überwachungsprotokoll",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160111",
          "display" : "Verlaufsdokumentationsbogen",
          "target" : [
            {
              "code" : "FPRO",
              "display" : "Therapiedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160112",
          "display" : "Pflegevisite",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160113",
          "display" : "Fallbesprechung Bezugspflegekraft",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160114",
          "display" : "Pflegenachweis",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160115",
          "display" : "Fotodokumentation Dekubitus",
          "target" : [
            {
              "code" : "FOTO",
              "display" : "Fotodokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL160199",
          "display" : "Sonstiger Pflegedokumentationsbogen",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230101",
          "display" : "Wunddokumentationsbogen",
          "target" : [
            {
              "code" : "WUND",
              "display" : "Wunddokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230102",
          "display" : "Bewegungs- und Lagerungsplan",
          "target" : [
            {
              "code" : "PFLG",
              "display" : "Pflegedokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230103",
          "display" : "Fotodokumentation Wunden",
          "target" : [
            {
              "code" : "WUND",
              "display" : "Wunddokumentation",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "VL230199",
          "display" : "Sonstige Wunddokumentation",
          "target" : [
            {
              "code" : "WUND",
              "display" : "Wunddokumentation",
              "equivalence" : "wider"
            }
          ]
        }
      ]
    },
    {
      "source" : "http://dvmd.de/fhir/CodeSystem/kdl",
      "target" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "element" : [
        {
          "code" : "UB140101",
          "display" : "Behördliche Genehmigung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140102",
          "display" : "Dokumentation vorhandender Infrastruktur",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140199",
          "display" : "Sonstiger Nachweis Infrastruktur",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140201",
          "display" : "Berufserlaubnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140202",
          "display" : "Approbation",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140203",
          "display" : "Arbeitsvertrag",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140204",
          "display" : "Arbeitszeugnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140205",
          "display" : "Dienstleistungsvereinbarung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140206",
          "display" : "Dienstplan",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140207",
          "display" : "Weiterbildungs-/Fortbildungs-/Qualifikationsnachweis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140208",
          "display" : "Ausbildungsbefugnis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140209",
          "display" : "Personalliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140210",
          "display" : "Auszug aus der Personalakte",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140211",
          "display" : "PuPGV-Nachweis",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140299",
          "display" : "Sonstiger Nachweis Personal",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140301",
          "display" : "Arzneimittelliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140302",
          "display" : "Inventarliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140303",
          "display" : "Medizinproduktebuch",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140304",
          "display" : "Geräteeinweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140399",
          "display" : "Sonstiger Nachweis sachliche Ausstattung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140401",
          "display" : "Aufstellung erbrachte Leistungen",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140402",
          "display" : "Aufstellung medizinische Angebote",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140403",
          "display" : "Dokumentation Behandlungsprogramm",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140404",
          "display" : "Fallliste",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140405",
          "display" : "Hygieneplan",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140406",
          "display" : "Organigramm",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140407",
          "display" : "Verfahrensanweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140408",
          "display" : "Dienstanweisung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140409",
          "display" : "Zertifizierungsurkunde",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB140499",
          "display" : "Sonstiger Nachweis Prozesse",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999997",
          "display" : "Gesamtdokumentation stationäre Versorgung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        },
        {
          "code" : "UB999998",
          "display" : "Gesamtdokumentation ambulante Versorgung",
          "target" : [
            {
              "code" : "UNK",
              "display" : "Unbekannt",
              "equivalence" : "wider"
            }
          ]
        }
      ]
    }
  ]
}

```
