# CodeSystem Klinische Dokumentenklassen-Liste (Version 2025) - v2025.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CodeSystem Klinische Dokumentenklassen-Liste (Version 2025)**

## CodeSystem: CodeSystem Klinische Dokumentenklassen-Liste (Version 2025) 

| | |
| :--- | :--- |
| *Official URL*:http://dvmd.de/fhir/CodeSystem/kdl | *Version*:2025.0.1 |
| Active as of 2025-01-01 | *Computable Name*:CodeSystemKDL |
| *Other Identifiers:*OID:1.2.276.0.76.5.553 | |
| **Copyright/Legal**: 2025 DVMD e.V. | |

 
Diese CodeSystem-Ressource definiert alle in der Klinischen Dokumentenklassen-Liste aktuell gültigen Codes. 

Die Klinische Dokumentenklassen-Liste (KDL) dient zur Klassierung medizinischer Dokumentation und unterstützt daher die Standardisierung und Interoperabilität. Die KDL umfasst Dokumententypen aus der stationären und ambulanten Versorgung, aber bereits auch aus der geriatrischen Pflege sowie klinischen Forschung und Rehabilitation.

Durch eine systematische Klassierung der vorhandenen Dokumente einer Einrichtung des Gesundheitswesens mit der KDL wird die Standardisierung auf einheitliche Dokumententypennamen erreicht, wobei die einrichtungsindividuellen Bezeichnungen nicht verloren gehen. Damit ist sichergestellt, dass die – für den Nutzer – relevanten Dokumentenbezeichnungen in den Anwendungssystemen erhalten bleiben und der Nutzer die gewohnten Bezeichnungen sieht.

Durch den Einsatz von bestehenden Mappingkonzepten wird der jeweilige Wartungsaufwand in den verschiedenen Anwendungssystemen spürbar minimiert.

Der Nutzen für den Einsatz der KDL liegt in den folgenden Bereichen:

* Transparenz über die verwendeteten Dokumententypen in der Einrichtung
* Bereitstellung bestimmter Dokumententypen für nutzerbezogene Rechercheanfragen bezogen auf enthaltene medizinische Informationen
* Bereitstellung der gesamten Akte im Dokumentenmanagementsystem und revisionssicherem Langzeitarchiv, d. h. Zusammenführung (Konsolidierung) von papierbasierten und elektronisch erzeugten Dokumenten sowie strukturierten Daten und Bildern
* Bereitstellung der gesamten strukturierten Akte für benutzerindividuelle Sichten
* intersektoraler Austausch, z. B. IHE-XDS konform, gemäß den Vorgaben des Medizinischen Dienstes oder externer Abrechnungsdienstleister der Klinik

Hinweise zur nachfolgenden tabellarischen Darstellung des CodeSystems:

*  

| | |
| :--- | :--- |
| Level 1 | Klassen |

 
*  

| | |
| :--- | :--- |
| Level 2 | Unterklassen |

 
*  

| | |
| :--- | :--- |
| Level 3 | Dokumenten(typ)klassen |

 
*  

| | |
| :--- | :--- |
| Code | Notation der Klasse, Unterklasse, Dokumenten(typ)klasse |

 
*  

| | |
| :--- | :--- |
| Display | Bezeichnung der Klasse, Unterklasse, Dokumentent(typ)klasse |

 
*  

| | |
| :--- | :--- |
| Definition | Beschreibung der Dokumenten(typ)klasse |

 

Für die Klassierung medizinischer Dokumente sind ausschließlich die Codes des Level 3 zu verwenden.

 This Code system is referenced in the content logical definition of the following value sets: 

* [ValueSetKDL](ValueSet-kdl-vs-2025.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "kdl-cs-2025",
  "url" : "http://dvmd.de/fhir/CodeSystem/kdl",
  "identifier" : [
    {
      "system" : "urn:ietf:rfc:3986",
      "value" : "urn:oid:1.2.276.0.76.5.553"
    }
  ],
  "version" : "2025.0.1",
  "name" : "CodeSystemKDL",
  "title" : "CodeSystem Klinische Dokumentenklassen-Liste (Version 2025)",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-01-01",
  "publisher" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
  "contact" : [
    {
      "name" : "Der Fachverband für Dokumentation und Informationsmanagement in der Medizin (DVMD)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.dvmd.de"
        },
        {
          "system" : "email",
          "value" : "dvmd@dvmd.de"
        }
      ]
    }
  ],
  "description" : "Diese CodeSystem-Ressource definiert alle in der Klinischen Dokumentenklassen-Liste aktuell gültigen Codes.",
  "copyright" : "2025 DVMD e.V.",
  "caseSensitive" : true,
  "hierarchyMeaning" : "is-a",
  "content" : "complete",
  "count" : 557,
  "property" : [
    {
      "code" : "status",
      "uri" : "http://hl7.org/fhir/concept-properties#status",
      "description" : "A property that indicates the status of the concept. One of active, experimental, deprecated,retired",
      "type" : "code"
    }
  ],
  "concept" : [
    {
      "code" : "AD",
      "display" : "Arztdokumentation",
      "concept" : [
        {
          "code" : "AD0101",
          "display" : "Arztberichte",
          "concept" : [
            {
              "code" : "AD010101",
              "display" : "Ärztliche Stellungnahme",
              "definition" : "Die Dokumentation beinhaltet die ärztliche Einschätzung zum Gesundheitszustand für nachfolgende Zwecke. Inkl.: Gutachten, Unfallanzeige, KBV Muster 36, PTV5/8, Ärztliches Zeugnis, Dokumentation von Therapiezielen/Therapiezieländerungen Exkl.: MD-Gutachten"
            },
            {
              "code" : "AD010102",
              "display" : "Durchgangsarztbericht",
              "definition" : "Die Dokumentation beinhaltet die ärztliche Beurteilung des Arbeits- bzw. Wegeunfalls auf standardisiertem Formular. Inkl.: Ergänzungsberichte D-Arzt (z. B. F1002, F1004, F1006, F1010, F1030, F1040, DUV F2222), Exkl.: Nachschaubericht"
            },
            {
              "code" : "AD010103",
              "display" : "Entlassungsbericht intern",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes. Erstellt von der entlassenden Einrichtung. Exkl.: Verlegungsbericht intern; Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD010115 (Entlassungsbericht) möglich."
            },
            {
              "code" : "AD010104",
              "display" : "Entlassungsbericht extern",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes. Erstellt von einer vorbehandelnden Einrichtung. Exkl.: Verlegungsbericht extern; Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD010115 (Entlassungsbericht) möglich."
            },
            {
              "code" : "AD010105",
              "display" : "Reha-Bericht",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung des Aufenthaltes während der Rehabilitation."
            },
            {
              "code" : "AD010106",
              "display" : "Verlegungsbericht intern",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes für die Verlegung auf eine andere Station, Fachbereich oder Einrichtung. Exkl.: Entlassungsbericht intern, Verlegungsschein intern; Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD010116 (Verlegungsbericht) möglich."
            },
            {
              "code" : "AD010107",
              "display" : "Verlegungsbericht extern",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes für die Verlegung von einer anderen Einrichtung. Erstellt von der vorbehandelnden Einrichtung. Exkl.: Entlassungsbericht extern;  Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD010116 (Verlegungsbericht) möglich."
            },
            {
              "code" : "AD010108",
              "display" : "Vorläufiger Arztbericht",
              "definition" : "Die Dokumentation beinhaltet die vorläufige Fassung des Entlassungsberichtes."
            },
            {
              "code" : "AD010109",
              "display" : "Ärztlicher Befundbericht",
              "definition" : "Die Dokumentation beinhaltet die ausführliche ärztliche Zusammenfassung von Befunden. Exkl.: Befundbogen"
            },
            {
              "code" : "AD010110",
              "display" : "Ärztlicher Verlaufsbericht",
              "definition" : "Die Dokumentation beinhaltet Angaben zum chronologischen Verlauf der Erkrankung und durchgeführten Maßnahmen aus Sicht des Arztes. Inkl.: Standardisierte Formulare zur ärztlichen Verlaufsdokumentation Exkl.: Visitenprotokoll"
            },
            {
              "code" : "AD010111",
              "display" : "Ambulanzbrief",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung einer ambulanten Behandlung in Briefform. Inkl.: Sprechstundenbrief"
            },
            {
              "code" : "AD010112",
              "display" : "Kurzarztbrief",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung des stationären Aufenthaltes in Kurzform."
            },
            {
              "code" : "AD010113",
              "display" : "Nachschaubericht",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Nachbehandlung eines Arbeits- bzw. Wegeunfalls durch den Durchgangsarzt auf standardisiertem Formular. Exkl.: Durchgangsarztbericht"
            },
            {
              "code" : "AD010114",
              "display" : "Interventionsbericht",
              "definition" : "Die Dokumentation beinhaltet diagnostische und therapeutische Interventionen/Eingriffe. Exkl.: Elektrokonvulsionstherapie, Herzkatheterprotokoll, Angiographiebefund, Punktionsprotokoll, OP Bericht, Endoskopiebefund"
            },
            {
              "code" : "AD010115",
              "display" : "Entlassungsbericht",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes."
            },
            {
              "code" : "AD010116",
              "display" : "Verlegungsbericht",
              "definition" : "Die Dokumentation beinhaltet die endgültige Zusammenfassung des stationären Aufenthaltes für die Verlegung auf eine andere Station, Fachbereich oder Einrichtung."
            },
            {
              "code" : "AD010199",
              "display" : "Sonstiger Arztbericht",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Autopsiebericht, Obduktionsbericht, Ärztliche Information (Briefform) des einweisenden bzw. überweisenden Arztes, Psychologischer Fachbericht"
            }
          ]
        },
        {
          "code" : "AD0201",
          "display" : "Bescheinigungen",
          "concept" : [
            {
              "code" : "AD020101",
              "display" : "Arbeitsunfähigkeitsbescheinigung",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Arbeitsunfähigkeit. Inkl.: AU KV 52"
            },
            {
              "code" : "AD020102",
              "display" : "Beurlaubung",
              "definition" : "Die Dokumentation beinhaltet die Erklärung über die Unterbrechung des stationären Aufenthaltes über einen festgelegten Zeitraum."
            },
            {
              "code" : "AD020103",
              "display" : "Todesbescheinigung",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Verstorbenen, zur Feststellung des Todes, zur Todesart sowie weiteren Zusatzangaben. Inkl.: Leichenbegleitschein, Sterbefallanzeige"
            },
            {
              "code" : "AD020104",
              "display" : "Ärztliche Bescheinigung",
              "definition" : "Die Dokumentation beinhaltet Bescheinigungen vom Arzt über z. B. die stationäre Behandlung, Atteste, Krankheitszustand. Exkl.: Arbeitsunfähigkeitsbescheinigung, Aufenthaltsbescheinigung Inkl.: KBV Muster 3 (Zeugnis über den mutmaßlichen Tag der Entbindung), 9 (Bescheinigung einer Frühgeburt oder einer Behinderung des Kindes), 21 (Ärztliche Bescheinigung für den Bezug von Krankengeld bei Erkrankung eines Kindes), 55 (Bescheinigung einer schwerwiegenden chronischen Erkrankung)"
            },
            {
              "code" : "AD020105",
              "display" : "Notfall-/Vertretungsschein",
              "definition" : "Die Dokumentation beinhaltet Diagnosen, Befunde, Therapien im Rahmen einer ambulanten Notfall-/Vertretungsbehandlung (KBV Muster 19). Exkl.: Abrechnungsschein, Überweisungsschein"
            },
            {
              "code" : "AD020106",
              "display" : "Wiedereingliederungsplan",
              "definition" : "Die Dokumentation beinhaltet Maßnahmen zur Wiedereingliederung in das Erwerbsleben (KBV Muster 20)."
            },
            {
              "code" : "AD020107",
              "display" : "Aufenthaltsbescheinigung",
              "definition" : "Die Dokumentation beinhaltet den Nachweis, in welchem Zeitraum der stationäre Aufenthalt stattgefunden hat."
            },
            {
              "code" : "AD020108",
              "display" : "Geburtsanzeige",
              "definition" : "Die Dokumentation beinhaltet administrative Angaben über die Eltern sowie das neugeborene Kind, welche an das Standesamt übermittelt werden."
            },
            {
              "code" : "AD020199",
              "display" : "Sonstige Bescheinigung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. z.B. Bescheinigungen, die auch von nicht-ärztlichen Berufsgruppen ausgestellt werden. Inkl.: Beratungsbescheinigung, administrative Bescheinigung über den Krankenhausaufenthalt, Schulbescheinigung Inkl.: KBV Muster 85 (Nachweis der Anspruchsberechtigung)"
            }
          ]
        },
        {
          "code" : "AD0202",
          "display" : "Befunderhebungen",
          "concept" : [
            {
              "code" : "AD020201",
              "display" : "Anatomische Skizze",
              "definition" : "Die Dokumentation beinhaltet anatomische Abbildungen, die zur Befunderhebung dienen."
            },
            {
              "code" : "AD020202",
              "display" : "Befundbogen",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse der ärztlichen Untersuchung. Exkl.: Funktionsdiagnostik, bildgebende Diagnostik, Funktionstest, Ärztlicher Befundbericht"
            },
            {
              "code" : "AD020203",
              "display" : "Bericht Gesundheitsuntersuchung",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse der ärztlichen Untersuchung, die von öffentlichen Trägern vorgegeben wird. Inkl.: Vorsorgeuntersuchungen, Befundbogen von Nachuntersuchungen Exkl.: Krebsfrüherkennung, Durchgangsarztbericht, Nachschaubericht, Ärztlicher Befundbericht"
            },
            {
              "code" : "AD020204",
              "display" : "Krebsfrüherkennung",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von empfohlenen Untersuchungen gemäß §25 SGB V zur Krebsfrüherkennung. z.B. Brustkrebs, Prostata Inkl.: KBV Muster 39 (Krebsfrüherkennung Zervix-Karzinom) und 40 (Krebsfrüherkennung Männer)"
            },
            {
              "code" : "AD020205",
              "display" : "Messblatt",
              "definition" : "Die Dokumentation beinhaltet Messungen von Teilen des Körpers, Gewicht und Körpergröße. Exkl.: Perzentilkurve"
            },
            {
              "code" : "AD020206",
              "display" : "Belastungserprobung",
              "definition" : "Die Dokumentation beinhaltet die Regelung zur Art und Dauer der Rückkehr in das Berufsleben. Inkl.: KBV-Formular F3110 und F3112"
            },
            {
              "code" : "AD020207",
              "display" : "Ärztlicher Fragebogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zu gezielten Fragen, die ausschließlich durch einen Arzt beantwortet werden. z.B. Ärztlicher Fragebogen zur Aufnahme in die vollstationäre Pflege, Kurzzeitpflege oder Tagespflege."
            },
            {
              "code" : "AD020208",
              "display" : "Befund extern",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von verschiedenen ärztlichen/therapeutischen Untersuchungen und Befunderhebungen, welche in vorbehandelnden Einrichtungen/Praxen entstanden sind, aber nicht durch eine spezifischere KDL abgebildet werden kann. Exkl. Laborbefund extern;  Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet."
            },
            {
              "code" : "AD020299",
              "display" : "Sonstige ärztliche Befunderhebung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "AD0601",
          "display" : "Fallbesprechungen",
          "concept" : [
            {
              "code" : "AD060101",
              "display" : "Konsilanforderung",
              "definition" : "Die Dokumentation beinhaltet die Anforderung/Anmeldung einer Befundung durch einen Facharzt aus einem weiteren Leistungsbereich."
            },
            {
              "code" : "AD060102",
              "display" : "Konsilanmeldung",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AD060103",
              "display" : "Konsilbericht intern",
              "definition" : "Die Dokumentation beinhaltet die Befundung und Empfehlung eines konsiliarischen Facharztes für den weiteren Behandlungsverlauf. Erstellt von der entlassenden Einrichtung.; Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD060110 (Konsilbericht) möglich."
            },
            {
              "code" : "AD060104",
              "display" : "Konsilbericht extern",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung der Befundung und Empfehlung eines Facharztes für den weiteren Behandlungsverlauf. Erstellt von einer Fremdeinrichtung. Inkl.: KBV Muster 22 (Konsiliarbericht vor Aufnahme einer Psychotherapie); Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL AD060110 (Konsilbericht) möglich. "
            },
            {
              "code" : "AD060105",
              "display" : "Visitenprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zu einer ärztlichen, therapeutischen und pflegerischen Besprechung zum aktuellen Zustand sowie weitere Maßnahmen. Visiten erfolgen in der Regel direkt im Beisein des zu Behandelnden. Exkl.: Ärztlicher Verlaufsbericht, Pflegevisite, Apotheke Visitenprotokoll"
            },
            {
              "code" : "AD060106",
              "display" : "Tumorkonferenzprotokoll",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AD060107",
              "display" : "Teambesprechungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zu einer interdisziplinären Beratung über den aktuellen Gesundheitszustand mit Risikeinschätzung, Indikationsstellung und der Planung des weiteren Verlaufes/Vorgehens inkl. beteiligte Berufsgruppen/Facharztgruppen (z.B. Herzteam-Protokoll). Exkl.: Tumorkonferenzprotokoll"
            },
            {
              "code" : "AD060108",
              "display" : "Anordnung/Verordnung",
              "definition" : "Die Dokumentation beinhaltet die Festlegung therapeutischer Maßnahmen. Inkl.: KBV Muster 63/64/65 (Verordnung spezialisierter ambulanter Palliativversorgung) Exkl.: Heil-/ Hilfsmittelverordnung, Rezept, Psychologische Therapieanordnung, Verordnung von Krankenhausbehandlung, Postoperative Verordnung, Bestrahlungsverordnung"
            },
            {
              "code" : "AD060109",
              "display" : "Verordnung",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AD060110",
              "display" : "Konsilbericht",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung der Befundung, die Einschätzung und Empfehlung eines Facharztes oder Apothekers/Apothekerin für den weiteren Behandlungsverlauf. Inkl.: KBV Muster 22 (Konsiliarbericht vor Aufnahme einer Psychotherapie), Exkl. AMTS-Prüfbericht"
            },
            {
              "code" : "AD060199",
              "display" : "Sonstige Fallbesprechung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Angehörigengespräch/Patientengespräch/Entlassungsgespräch, Gesprächsnotiz, Sprechstundenprotokoll"
            }
          ]
        }
      ]
    },
    {
      "code" : "AM",
      "display" : "Administration",
      "concept" : [
        {
          "code" : "AM0101",
          "display" : "Abrechnungsdokumente",
          "concept" : [
            {
              "code" : "AM010101",
              "display" : "Übersicht abrechnungsrelevanter Diagnosen / Prozeduren",
              "definition" : "Die Dokumentation beinhaltet alle Diagnosen und Leistungen im Rahmen einer Behandlung, welche die Grundlage zur Abrechnung beim jeweiligen Kostenträger bilden."
            },
            {
              "code" : "AM010102",
              "display" : "G-AEP Kriterien",
              "definition" : "Die Dokumentation beinhaltet festgelegte Kriterien zur Feststellung der Notwendigkeit einer stationären Behandlung. Inkl.: Indikationsbogen zur Aufnahme"
            },
            {
              "code" : "AM010103",
              "display" : "Kostenübernahmeverlängerung",
              "definition" : "Die Dokumentation beinhaltet die Bestätigung zur Kostenübernahme bei Weiterführung der Behandlung. Inkl.: Kostenübernahmeerklärung"
            },
            {
              "code" : "AM010104",
              "display" : "Schriftverkehr MD Kasse",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz in Bezug auf MD relevante Fälle zwischen MD und Krankenkasse. Exkl.: MD Prüfauftrag, MD Gutachten, Schriftverkehr MD Arzt"
            },
            {
              "code" : "AM010105",
              "display" : "Abrechnungsschein",
              "definition" : "Die Dokumentation beinhaltet Angaben, die als Nachweis über die erfolgte ambulante Behandlung und deren Abrechnung dient. Inkl.: KBV Muster 5 Exkl.: Notfall-/Vertretungsschein, Überweisungsschein"
            },
            {
              "code" : "AM010106",
              "display" : "Rechnung ambulante/stationäre Behandlung",
              "definition" : "Die Dokumentation beinhaltet eine individuelle Kostenerstellung der erbrachten Leistungen an den jeweiligen Kostenträger."
            },
            {
              "code" : "AM010107",
              "display" : "MD Prüfauftrag",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Ankündigung zur Überprüfung eines abrechnungsrelevanten Sachverhaltes oder einer Leistungsgruppen/StrOPS-Prüfung durch den Medizinischen Dienst.  Exkl.: Schriftverkehr MD Kasse, MD Gutachten, Schriftverkehr MD Arzt"
            },
            {
              "code" : "AM010108",
              "display" : "MD Gutachten",
              "definition" : "Die Dokumentation beinhaltet das Ergebnis einer Begutachtung durch den Medizinischen Dienst, wie z. B. Einzelfallgutachten, Korrekturgutachten, Strukturgutachten, Grundsatzgutachten, Qualitätskontrollberichte."
            },
            {
              "code" : "AM010109",
              "display" : "Begründete Unterlagen Leistungskodierung",
              "definition" : "Die Dokumentation beinhaltet Informationen aus anerkannten Referenzen, wie z. B. Kodierrichtlinien, FoKA, DGfM, SEG 4, FPV, Schlichtungsausschuss, Urteile zu Kodierfragen."
            },
            {
              "code" : "AM010110",
              "display" : "Heil- und Kostenplan",
              "definition" : "Die Dokumentation beinhaltet Angaben, welche Behandlungen erfolgen sollen und wie hoch die voraussichtlichen Kosten sind. Inkl. KZBV Muster, gem. TI-Spezifikation"
            },
            {
              "code" : "AM010111",
              "display" : "Kostenvoranschlag",
              "definition" : "Die Dokumentation beinhaltet Angaben, welche Behandlungen erfolgen sollen und wie hoch die voraussichtlichen Kosten sind."
            },
            {
              "code" : "AM010199",
              "display" : "Sonstige Abrechnungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Dokumentation erbrachte Leistungen (GOÄ), Einzahlungsquittung, Individual Checkliste, Liquidation, Zahlungsaufforderung, Checkliste Abrechnung, Entlassungsschein"
            }
          ]
        },
        {
          "code" : "AM0102",
          "display" : "Anträge",
          "concept" : [
            {
              "code" : "AM010201",
              "display" : "Antrag auf Rehabilitation",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage an den zuständigen Kostenträger für Maßnahmen zum Erhalt oder Verbesserung des Gesundheitszustandes. Inkl.: KBV Muster 25 (Anregung einer ambulanten Vorsorgeleistung in anerkannten Kurorten), Ärztlicher Befundbericht zum AHB Antrag"
            },
            {
              "code" : "AM010202",
              "display" : "Antrag auf Betreuung",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage auf eine gesetzliche Vormundschaft durch das Gericht."
            },
            {
              "code" : "AM010203",
              "display" : "Antrag auf gesetzliche Unterbringung",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage bei Gericht auf Unterbringung von Patienten*innen aller Altersgruppen in eine geschlossene Einrichtung durch einen Arzt, wenn freiheitsentziehende Maßnahmen erforderlich sind. Exkl.: Antrag auf Fixierung beim Amtsgericht"
            },
            {
              "code" : "AM010204",
              "display" : "Verlängerungsantrag",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage zur Übernahme der Kosten bei Weiterführung der Behandlung / Rehabilitation."
            },
            {
              "code" : "AM010205",
              "display" : "Antrag auf Psychotherapie",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage für eine gezielte professionelle Behandlung psychischer Störungen. Inkl.: KBV Muster PTV1/PTV2"
            },
            {
              "code" : "AM010206",
              "display" : "Antrag auf Pflegeeinstufung",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage an den MD zur Genehmigung eines Pflegegrades bei Pflegebedürftigkeit."
            },
            {
              "code" : "AM010207",
              "display" : "Kostenübernahmeantrag",
              "definition" : "Die Dokumentation beinhaltet eine Anfrage zur Kostenübernahme für eine geplante Behandlung. Inkl.: KBV Muster 56"
            },
            {
              "code" : "AM010208",
              "display" : "Antrag auf Leistungen der Pflegeversicherung",
              "definition" : "Die Dokumentation beinhaltet einen Antrag zur Inanspruchnahme von Leistungen, welche durch die Pflegeversicherung übernommen werden sollen. Beispiel: Pflegegeld, Pflegehilfsmittel, etc."
            },
            {
              "code" : "AM010209",
              "display" : "Antrag auf Kurzzeitpflege",
              "definition" : "Die Dokumentation beinhaltet einen Antrag zur Inanspruchnahme einer begrenzten oder vollstationären Pflege einer pflegebedürftigen Person."
            },
            {
              "code" : "AM010210",
              "display" : "Antrag auf Fixierung/Isolierung beim Amtsgericht",
              "definition" : "Die Dokumentation beinhaltet die Anfrage beim Gericht auf notwendige Fixierungs- oder Isolierungsmaßnahmen."
            },
            {
              "code" : "AM010211",
              "display" : "Antrag abrechnungsrelevante OPS-Kodes",
              "definition" : "Die Dokumentation enthält den Antrag gemäß der Richtlinie des Medizinischen Dienstes Bund nach § 283 Absatz 2 Satz 1  Nr.3 SGBV zu den regelmäßigen Begutachtungen zur Einhaltung von Strukturmerkmalen  von OPS-Kodes nach § 275d SGB V "
            },
            {
              "code" : "AM010299",
              "display" : "Sonstiger Antrag",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Antrag auf Haushaltshilfe"
            }
          ]
        },
        {
          "code" : "AM0103",
          "display" : "Aufklärungen",
          "concept" : [
            {
              "code" : "AM010301",
              "display" : "Anästhesieaufklärungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Aufklärung der geplanten Anästhesie. Inkl.: Anamnese, Begleitmedikation, geplanter Eingriff, Vitaldaten, Präoperative Visite"
            },
            {
              "code" : "AM010302",
              "display" : "Diagnostischer Aufklärungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Aufklärung der geplanten Diagnostik, inklusive anamnestischer Erhebungen."
            },
            {
              "code" : "AM010303",
              "display" : "Operationsaufklärungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Aufklärung der geplanten Operation, inklusive anamnestischer Erhebungen."
            },
            {
              "code" : "AM010304",
              "display" : "Aufklärungsbogen Therapie",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Aufklärung der geplanten Therapie, inklusive anamnestischer Erhebungen."
            },
            {
              "code" : "AM010399",
              "display" : "Sonstiger Aufklärungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Aufklärung - Zentralvenöser Katheter, Aufklärungsbogen - Geburtseinleitung, Aufklärung - Anwesenheit des Vaters/ einer Vertrauensperson bei der Entbindung, Aufklärung - Eigenblutspende einschließlich Eigenblutrückübertragung"
            }
          ]
        },
        {
          "code" : "AM0301",
          "display" : "Checklisten Administration",
          "concept" : [
            {
              "code" : "AM030101",
              "display" : "Aktenlaufzettel",
              "definition" : "Die Dokumentation beinhaltet einen Nachweis über den aktuellen Verbleib sowie den Aktenlauf."
            },
            {
              "code" : "AM030102",
              "display" : "Checkliste Entlassung",
              "definition" : "Die Dokumentation beinhaltet Angaben, ob die zur Entlassung notwendigen Dokumente/Gegenstände vollständig sind. Inkl.: Checkliste Entlassgespräch, Checkliste zur Verlegung"
            },
            {
              "code" : "AM030103",
              "display" : "Entlassungsplan",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Vorbereitung einer Entlassung nach stationärem Aufenthalt."
            },
            {
              "code" : "AM030104",
              "display" : "Patientenlaufzettel",
              "definition" : "Die Dokumentation beinhaltet einen Nachweis über Terminvereinbarungen, durchgeführte Diagnostiken, Behandlungen o.ä. während des Aufenthaltes."
            },
            {
              "code" : "AM030199",
              "display" : "Sonstige Checkliste Administration",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Aktendeckblatt, Aktencheckliste, Checkliste zur Archivierung der Krankengeschichte"
            }
          ]
        },
        {
          "code" : "AM0501",
          "display" : "Einwilligungen/Erklärungen",
          "concept" : [
            {
              "code" : "AM050101",
              "display" : "Datenschutzerklärung",
              "definition" : "Die Dokumentation beinhaltet eine Erklärung zum Schutz von sensiblen Daten und deren Verwendung ."
            },
            {
              "code" : "AM050102",
              "display" : "Einverständniserklärung",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AM050103",
              "display" : "Erklärung Nichtansprechbarkeit Patienten",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AM050104",
              "display" : "Einverständniserklärung Abrechnung",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Erlaubnis, sensible Daten zu Abrechnungszwecken an Dritte weiterzugeben."
            },
            {
              "code" : "AM050105",
              "display" : "Einverständniserklärung Behandlung",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Erlaubnis um eine geplante Behandlung durchführen und dokumentieren zu können. Inkl.: Einwilligungserklärung Fotodokumentation, Einverständniserklärung Neugeborenenscreening, Einwilligung Apotheke (bspw. zur Herstellung von Arzneimitteln); Exkl.: Einwilligungen im Rahmen der medizinischen Aufklärung (Unterklasse Aufklärungen (AM0103))"
            },
            {
              "code" : "AM050106",
              "display" : "Einwilligung und Datenschutzerklärung Entlassungsmanagement",
              "definition" : "Die Dokumentation beinhaltet ein bundeseinheitliches Formular zu Inhalten und Zielen des Entlassmanagement mit schriftlicher Einwilligung zur Datenübermittlung an die Krankenkasse mit Widerruf."
            },
            {
              "code" : "AM050107",
              "display" : "Schweigepflichtentbindung",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Einwilligung um medizinische Daten, die der ärztlichen Schweigepflicht unterliegen, an Dritte weitergeben zu dürfen."
            },
            {
              "code" : "AM050108",
              "display" : "Entlassung gegen ärztlichen Rat",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Einwilligung, die stationäre Behandlung vorzeitig gegen ärztlichen Rat abzubrechen."
            },
            {
              "code" : "AM050109",
              "display" : "Aufforderung zur Herausgabe der medizinischen Dokumentation",
              "definition" : "Die Dokumentation beinhaltet eine Anweisung die Akte/Daten des Mandanten herauszugeben (Art. 15 DSGVO)."
            },
            {
              "code" : "AM050110",
              "display" : "Aufforderung zur Löschung der medizinischen Dokumentation",
              "definition" : "Die Dokumentation beinhaltet eine Anweisung die Akte/Daten des Mandanten zu löschen (Art. 17 DSGVO)."
            },
            {
              "code" : "AM050111",
              "display" : "Aufforderung zur Berichtigung der medizinischen Dokumentation",
              "definition" : "Die Dokumentation beinhaltet eine Anweisung die Akte/Daten des Mandanten zu berichtigen (Art. 16 DSGVO)."
            },
            {
              "code" : "AM050199",
              "display" : "Sonstige Einwilligung/Erklärung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Abtretungserklärung, Aushändigung der Explantate, Einwilligung zum Tragen des Patientenidentifikationsarmbandes, Patientenerklärung Europäische Krankenversicherung, Zustimmungserklärung. Exkl.: Einwilligungen im Rahmen der medizinischen Aufklärung (Unterklasse Aufklärungen (AM0103))"
            }
          ]
        },
        {
          "code" : "AM1601",
          "display" : "Patienteneigene Dokumente",
          "concept" : [
            {
              "code" : "AM160101",
              "display" : "Blutgruppenausweis",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Blutgruppe und zum Rhesusfaktor."
            },
            {
              "code" : "AM160102",
              "display" : "Impfausweis",
              "definition" : "Die Dokumentation beinhaltet Angaben zu durchgeführten Impfungen mit Angaben zur Charge."
            },
            {
              "code" : "AM160103",
              "display" : "Vorsorgevollmacht",
              "definition" : "Die Dokumentation beinhaltet die schriftliche Bevollmächtigung, bestimmte Interessen Dritter zu vertreten."
            },
            {
              "code" : "AM160104",
              "display" : "Patientenverfügung",
              "definition" : "Die Dokumentation beinhaltet den vorsorglich festgehaltenen letzten Willen."
            },
            {
              "code" : "AM160105",
              "display" : "Wertgegenständeverwaltung",
              "definition" : "Die Dokumentation beinhaltet eine Sachauflistung zu Gegenständen, die bei Aufnahme mit in die Einrichtung gebracht wurden. Inkl.: Nachweise über Ein- und Ausgang von Geld, Verlustmeldungen"
            },
            {
              "code" : "AM160106",
              "display" : "Allergiepass",
              "definition" : "Die Dokumentation beinhaltet eine vollständige Auflistung zu bekannten Allergien in Form eines Ausweises."
            },
            {
              "code" : "AM160107",
              "display" : "Herzschrittmacherausweis",
              "definition" : "Die Dokumentation beinhaltet Angaben zum implantierten Schrittmacher einer Person in Form eines Ausweises."
            },
            {
              "code" : "AM160108",
              "display" : "Nachlassprotokoll",
              "definition" : "Die Dokumentation beinhaltet ein Übergabeprotokoll, mit dem aufgelisteten Nachlass."
            },
            {
              "code" : "AM160109",
              "display" : "Mutterpass (Kopie)",
              "definition" : "Die Dokumentation beinhaltet Angaben in dem alle relevanten Daten zum Schwangerschaftsverlauf erfasst werden."
            },
            {
              "code" : "AM160110",
              "display" : "Ausweiskopie",
              "definition" : "Die Dokumentation beinhaltet die Kopie eines Ausweisdokumentes. Exkl.: Herzschrittmacherausweis, Implantat-Ausweis"
            },
            {
              "code" : "AM160111",
              "display" : "Implantat-Ausweis",
              "definition" : "Die Dokumentation beinhaltet Angaben zu Implantaten einer Person."
            },
            {
              "code" : "AM160112",
              "display" : "Betreuerausweis",
              "definition" : "Die Dokumentation beinhaltet Angaben über einen gesetzlichen Vertreter einer Person."
            },
            {
              "code" : "AM160113",
              "display" : "Patientenbild",
              "definition" : "Die Dokumentation beinhaltet Fotos von Patienten, welche aus administrativen Gründen angefertigt wurden. Für Fotografien, die im Zusammenhang mit der Behandlung stehen, sind die spezifischeren KDL-Kodes zu verwenden."
            },
            {
              "code" : "AM160199",
              "display" : "Sonstiges patienteneigenes Dokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Ausweis Antikoagulanzienbehandlung, Urkunde (Notar), Zeugnis"
            }
          ]
        },
        {
          "code" : "AM1602",
          "display" : "Patienteninformationen",
          "concept" : [
            {
              "code" : "AM160201",
              "display" : "Belehrung",
              "definition" : "Die Dokumentation beinhaltet eine Aufklärung bzw. Anweisung wie, wann und wo eine bestimmte Handlung bzw. ein Verhalten auszuführen ist. Exkl. Arzneimittelinformation"
            },
            {
              "code" : "AM160202",
              "display" : "Informationsblatt",
              "definition" : "Die Dokumentation beinhaltet wichtige Hinweise, die für eine Behandlung oder stationären Aufenthalt notwendig sind. Inkl. KBV Muster PTV 10/11, Exkl. Arzneimittelinformation"
            },
            {
              "code" : "AM160203",
              "display" : "Informationsblatt Entlassungsmanagement",
              "definition" : "Die Dokumentation beinhaltet Informationen, die den Patienten über die lückenlose Anschlussversorgung nach dem Krankenhausaufenthalt aufklären."
            },
            {
              "code" : "AM160299",
              "display" : "Sonstiges Patienteninformationsblatt",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "AM1603",
          "display" : "Poststationäre Verordnungen",
          "concept" : [
            {
              "code" : "AM160301",
              "display" : "Heil- / Hilfsmittelverordnung",
              "definition" : "Die Dokumentation beinhaltet eine ärztliche Anweisung zur Durchführung von therapeutischen Behandlungen (Bsp. Physiotherapie, Ergotherapie, Logotherapie etc.) sowie die Verordnung von Hilfsmitteln zur therapeutischen Unterstützung (Bsp. Bandagen, Gehilfen, Prothesen etc.). Inkl.: KBV Muster 8 (Sehhilfenverordnung), 8a (Verordnung von vergrößernden Sehhilfen), 13 (Heilmittelverordnung Physikalische Th.), 14, 15 (Verordnung einer Hörhilfe), 18 (Verordnung Ergotherapie), 28 (Verordnung Soziotherapie)"
            },
            {
              "code" : "AM160302",
              "display" : "Krankentransportschein",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über durchgeführte oder geplante Krankenbeförderungen. Inkl.: KBV Muster 4 (Verordnung einer Krankenbeförderung), Anforderung eines Krankentransportes"
            },
            {
              "code" : "AM160303",
              "display" : "Verordnung häusliche Krankenpflege",
              "definition" : "Die Dokumentation beinhaltet eine ärztliche Anweisung für die Krankenpflege zu Hause (KBV Muster 12)."
            },
            {
              "code" : "AM160399",
              "display" : "Sonstige poststationäre Verordnung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: KBV Muster 61, Verordnung von medizinischer Rehabilitation, Ärztliche Verordnung zur nachstationären Versorgung"
            }
          ]
        },
        {
          "code" : "AM1701",
          "display" : "Qualitätssicherungen",
          "concept" : [
            {
              "code" : "AM170101",
              "display" : "Dokumentationsbogen Meldepflicht",
              "definition" : "Die Dokumentation beinhaltet meldepflichtigen Daten an Dritte. Inkl.: Infektionserkrankungen, Krankheitserreger, unerwünschte Ereignisse durch Medizinprodukte"
            },
            {
              "code" : "AM170102",
              "display" : "Hygienestandard",
              "definition" : "Die Dokumentation beinhaltet eine festgelegte Leitlinie bezüglich der Durchführung von Hygienemaßnahmen zum Vermeiden von Gesundheitsschäden durch Erreger."
            },
            {
              "code" : "AM170103",
              "display" : "Patientenfragebogen",
              "definition" : "Die Dokumentation beinhaltet Fragen bzgl. relevanter Informationen zur Verbesserung eines Behandlungsprozesses. Inkl.: Fragebogen Beckenboden präoperativ, Fragebogen zur Tagesschläfrigkeit, Patientenumfragen, Angehörigenfragebogen Exkl.: Fragebogen zur Anamneseerhebung (Anamnesebogen)"
            },
            {
              "code" : "AM170104",
              "display" : "Pflegestandard",
              "definition" : "Die Dokumentation beinhaltet standardisierte Vorgaben zur Durchführung von Pflegemaßnahmen."
            },
            {
              "code" : "AM170105",
              "display" : "Qualitätssicherungsbogen",
              "definition" : "Die Dokumentation beinhaltet gesetzlich vorgeschriebene Qualitätssicherungsverfahren. Inkl.: laut IQTIG"
            },
            {
              "code" : "AM170199",
              "display" : "Sonstiges Qualitätssicherungsdokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Komplikationsbogen, Leitfäden, Nachbehandlungsschema, Leitlinien, Verfahrensanweisung. Exkl.: SOP im Kontext Klinische Studien"
            }
          ]
        },
        {
          "code" : "AM1901",
          "display" : "Schriftverkehr",
          "concept" : [
            {
              "code" : "AM190101",
              "display" : "Anforderung Unterlagen",
              "definition" : "Die Dokumentation beinhaltet eine Anforderung von Unterlagen, die für den aktuellen Behandlungsverlauf relevant sind. Exkl.: Anforderung Unterlagen MD"
            },
            {
              "code" : "AM190102",
              "display" : "Schriftverkehr Amtsgericht",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz zwischen medizinischer Einrichtung und Amtsgericht. Inkl.: Bestellungsurkunde, Betreuer, Beschluss"
            },
            {
              "code" : "AM190103",
              "display" : "Schriftverkehr MD Arzt",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz zwischen Arzt und Medizinischen Dienst. Inkl. KBV Muster 11 (Bericht für den Medizinischen Dienst), Muster 86 (Weiterleitungsbogen für angeforderte Befunde an den MD)"
            },
            {
              "code" : "AM190104",
              "display" : "Schriftverkehr Krankenkasse",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz zwischen medizinischer Einrichtung und Krankenkasse. Inkl.: KBV Muster 50/51, PTV4 Exkl.: Widerspruchsbegründung"
            },
            {
              "code" : "AM190105",
              "display" : "Schriftverkehr Deutsche Rentenversicherung",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz zwischen medizinischer Einrichtung und der deutschen Rentenversicherung."
            },
            {
              "code" : "AM190106",
              "display" : "Sendebericht",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über das Versenden eines Fax."
            },
            {
              "code" : "AM190107",
              "display" : "Empfangsbestätigung",
              "definition" : "Die Dokumentation beinhaltet einen Nachweis für den Empfang sowie über die Ausgabe von Dokumenten, Medikamenten, Hilfsmittel usw."
            },
            {
              "code" : "AM190108",
              "display" : "Handschriftliche Notiz",
              "definition" : "Die Dokumentation beinhaltet ausschließlich handschriftliche Informationen auf einem formlosen Bogen."
            },
            {
              "code" : "AM190109",
              "display" : "Lieferschein",
              "definition" : "Die Dokumentation beinhaltet Angaben über eine Lieferung."
            },
            {
              "code" : "AM190110",
              "display" : "Schriftverkehr Amt/Gericht/Anwalt",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenzen mit Ämtern, Gerichten oder Anwälten. Exkl.: Schriftverkehr Amtsgericht, Schriftverkehr Strafverfolgung und Schadensersatz"
            },
            {
              "code" : "AM190111",
              "display" : "Schriftverkehr Strafverfolgung und Schadensersatz",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenzen mit Ämtern und Behörden, die im Rahmen der Strafverfolgung, Fahndung oder Schadensersatz entsteht. Exkl.: Schriftverkehr Amt/Gericht/Anwalt, Schriftverkehr Amtsgericht"
            },
            {
              "code" : "AM190112",
              "display" : "Anforderung Unterlagen MD",
              "definition" : "Die Dokumentation beinhaltet eine Liste mit den zur Prüfung der Abrechnung notwendigen Unterlagen in der Klassifikation nach IHE/KDL (gem. Abschnitt 6.2, Anlage 1,eVV) oder zur Leistungsgruppen/StrOPS-Prüfung durch den Medizinischen Dienst. Exkl.: Anforderung Unterlagen"
            },
            {
              "code" : "AM190113",
              "display" : "Widerspruchsbegründung",
              "definition" : "Die Dokumentation beinhaltet den (medizinischen) Widerspruch gegen einen Leistungsentscheid. Exkl.: Ärztlicher Widerspruch im laufenden MD-Verfahren (Schriftkehr MD Arzt)"
            },
            {
              "code" : "AM190114",
              "display" : "Schriftverkehr Unfallversicherungsträger und Leistungserbringer",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenz zwischen medizinischer Einrichtung und dem Unfallversicherungsträger."
            },
            {
              "code" : "AM190199",
              "display" : "Sonstiger Schriftverkehr",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: KBV Muster 53 (Anfrage zum Zusammenhang von Arbeitsunfähigkeitszeiten), Mitteilung Termin, Übersendung Unterlagen, Mitteilung Termin stationäre Aufnahme"
            }
          ]
        },
        {
          "code" : "AM1902",
          "display" : "Sozialdienst",
          "concept" : [
            {
              "code" : "AM190201",
              "display" : "Beratungsbogen Sozialer Dienst",
              "definition" : "Die Dokumentation beinhaltet Angaben des Sozialdienstes zu empfohlenen Maßnahmen. Beinhaltet auch Notizen des Gesprächsverlaufes und festgelegte Vereinbarungen."
            },
            {
              "code" : "AM190202",
              "display" : "Soziotherapeutischer Betreuungsplan",
              "definition" : "Die Dokumentation beinhaltet Angaben mit Therapiezielen, verordneten empfohlenen Maßnahmen usw., welche durch den Sozialen Dienst an die Krankenkasse weitergeleitet werden. Inkl.: Muster 27 (KBV)"
            },
            {
              "code" : "AM190203",
              "display" : "Einschätzung Sozialdienst",
              "definition" : "Die Dokumentation beinhaltet eine Einschätzung eines Patienten durch den Sozialdienst."
            },
            {
              "code" : "AM190204",
              "display" : "Abschlussbericht Sozialdienst",
              "definition" : "Die Dokumentation beinhaltet einen Bericht bzw. eine Zusammenfassung eines Patientenfalls bezüglich der nachstationären Betreuung oder weiteren Behandlung."
            },
            {
              "code" : "AM190299",
              "display" : "Sonstiges Dokument Sozialdienst",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Anforderung Sozialdienst, Meldung an Sozialdienst, Verlaufsdokumentation Sozialdienst"
            }
          ]
        },
        {
          "code" : "AM2201",
          "display" : "Verträge",
          "concept" : [
            {
              "code" : "AM220101",
              "display" : "Behandlungsvertrag",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Umfang einer Behandlung und die damit verbundenen Rechte und Pflichten zwischen  Einrichtung und Patient."
            },
            {
              "code" : "AM220102",
              "display" : "Wahlleistungsvertrag",
              "definition" : "Die Dokumentation beinhaltet Angaben zu zusätzlich gewählten Leistungen, während einer Behandlung, zwischen Einrichtung und Patient."
            },
            {
              "code" : "AM220103",
              "display" : "Heimvertrag",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Vertrag zwischen einer Einrichtung und einem Bewohner."
            },
            {
              "code" : "AM220104",
              "display" : "Angaben zur Vergütung von Mitarbeitenden",
              "definition" : "Die Dokumentation beinhaltet Namen und Vergütung der Mitarbeiter mit abgeschlossener Ausbildung, die zur Überwachung und/oder Behandlung von Patientinnen und Patienten eingesetzt werden."
            },
            {
              "code" : "AM220199",
              "display" : "Sonstiger Vertrag",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Allgemeine Vertragsbedingungen, Individuelle Vereinbarungen"
            }
          ]
        }
      ]
    },
    {
      "code" : "AU",
      "display" : "Aufnahme",
      "concept" : [
        {
          "code" : "AU0101",
          "display" : "Aufnahmedokumente",
          "concept" : [
            {
              "code" : "AU010101",
              "display" : "Anamnesebogen",
              "definition" : "Die Dokumentation beinhaltet medizinische, relevante Informationen zur Vorgeschichte. Inkl.: Krankengeschichte"
            },
            {
              "code" : "AU010102",
              "display" : "Anmeldung Aufnahme",
              "definition" : "Die Dokumentation beinhaltet persönliche und organisatorische Angaben zur Aufnahme. Inkl. KBV Muster PTV12"
            },
            {
              "code" : "AU010103",
              "display" : "Aufnahmebogen",
              "definition" : "Die Dokumentation beinhaltet den Befund des aktuellen Zustands bei Aufnahme und Informationen zur Vorgeschichte. Inkl.: Aufahmebefund, Aufnahmeblatt, Krankenblatt"
            },
            {
              "code" : "AU010104",
              "display" : "Checkliste Aufnahme",
              "definition" : "Die Dokumentation beinhaltet Angaben über erforderliche medizinische, organisatorische Maßnahmen zum Aufnahmezeitpunkt. Erfolgte Durchführungen werden gekennzeichnet."
            },
            {
              "code" : "AU010105",
              "display" : "Stammblatt",
              "definition" : "Die Dokumentation beinhaltet zusammengefasst administrative und persönliche Daten im Überblick."
            },
            {
              "code" : "AU010199",
              "display" : "Sonstige Aufnahmedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Aufnahmegespräch, Übersicht über bisherigen Behandlungverlauf, Aufnahme/Mitaufnahme Begleitperson Exkl.: Covid Fragebogen (Dokumentation COVID)"
            }
          ]
        },
        {
          "code" : "AU0501",
          "display" : "Einweisungs-/ Überweisungsdokumente",
          "concept" : [
            {
              "code" : "AU050101",
              "display" : "Verordnung von Krankenhausbehandlung",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Grund der stationären Aufnahme. Standardisiertes Einweisungsdokument gemäß Kassenärztliche Bundesvereinigung (KBV Muster 2)."
            },
            {
              "code" : "AU050102",
              "display" : "Überweisungsschein",
              "definition" : "Die Dokumentation beinhaltet Angaben zur geplanten Behandlungsart, Fachabteilung, Diagnosen, Behandlungsauftrag, Vertragsarzt. Inkl.: standardisierter Überweisungsschein gem. Kassenärztliche Bundesvereinigung (KBV Muster 6 und 7), Überweisung D-Arzt. Exkl.: Abrechnungsschein, Notfall/Vertretungsschein"
            },
            {
              "code" : "AU050103",
              "display" : "Überweisungsschein Entlassung",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AU050104",
              "display" : "Verlegungsschein Intern",
              "definition" : "Die Dokumentation beinhaltet Angaben zur krankenhausinternen Verlegung auf eine andere Station oder einen Fachbereich. Exkl.: Verlegungsbericht, Ärztliche Stellungnahme"
            },
            {
              "code" : "AU050199",
              "display" : "Sonstiges Einweisungs-/Überweisungsdokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden können. Inkl.: telefonische Überweisung, Patient Admission Form"
            }
          ]
        },
        {
          "code" : "AU1901",
          "display" : "Rettungsstelle",
          "concept" : [
            {
              "code" : "AU190101",
              "display" : "Einsatzprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben über den notarztspezifischen Einsatz. Inkl.: Rettungsstellenprotokoll, Nothilfeprotokoll"
            },
            {
              "code" : "AU190102",
              "display" : "Notaufnahmebericht",
              "definition" : "Die Dokumentation beinhaltet den ärztlichen Bericht über die Behandlung in der Notaufnahme."
            },
            {
              "code" : "AU190103",
              "display" : "Notaufnahmebogen",
              "definition" : "Die Dokumentation beinhaltet den Befund des aktuellen Zustands in der Notaufnahme (inkl. Triage)"
            },
            {
              "code" : "AU190104",
              "display" : "Notfalldatensatz",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "AU190105",
              "display" : "ISAR Screening",
              "definition" : "Die Dokumentation beinhaltet Angaben für das Screening zur Ermittlung des geriatrischen Hilfebedarfs."
            },
            {
              "code" : "AU190199",
              "display" : "Sonstige Dokumentation Rettungsstelle",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: ZNA Notfallschein, Checkliste Notfallambulanz"
            }
          ]
        }
      ]
    },
    {
      "code" : "DG",
      "display" : "Diagnostik",
      "concept" : [
        {
          "code" : "DG0201",
          "display" : "Bildgebende Diagnostiken",
          "concept" : [
            {
              "code" : "DG020101",
              "display" : "Anforderung bildgebende Diagnostik",
              "definition" : "Die Dokumentation beinhaltet die Anforderung oder Anmeldung einer Diagnostik durch ärztliches Personal, bei der die Untersuchungsergebnisse bildlich dargestellt werden."
            },
            {
              "code" : "DG020102",
              "display" : "Angiographiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer speziellen radiologischen Untersuchung, bei der Arterien, Venen oder Lymphbahnen bildlich dargestellt und ausgewertet werden. Inkl.: Phlebographiebefund Exkl.: Herzkatheterprotokoll"
            },
            {
              "code" : "DG020103",
              "display" : "CT-Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer speziellen radiologischen Untersuchung. Es entsteht ein mehrdimensionaler Querschnitt von Knochen und Weichteilen, welcher bildlich dargestellt und ausgewertet wird. Exkl.: PET-Befund"
            },
            {
              "code" : "DG020104",
              "display" : "Echokardiographiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer ultraschallgestützten Untersuchung der Struktur und Funktion des Herzens, welche bildlich dargestellt und ausgewertet werden."
            },
            {
              "code" : "DG020105",
              "display" : "Endoskopiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung bei der Körperhöhlen und Hohlorgane von innen bildlich dargestellt und ausgewertet werden."
            },
            {
              "code" : "DG020106",
              "display" : "Herzkatheterprotokoll",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer minimalinvasiven Untersuchung des Herzens, unter radiologischer Kontrolle, über einen speziellen Katheter. Exkl.: Angiographieprotokoll"
            },
            {
              "code" : "DG020107",
              "display" : "MRT-Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer speziellen radiologischen Untersuchung, bei der Schnittbilder von Knochen und Weichteilen im menschlichen Körper, mit Hilfe von Magnetfeldern, bildlich dargestellt und ausgewertet werden."
            },
            {
              "code" : "DG020108",
              "display" : "OCT-Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer tomographischen Untersuchung, bei der mehrdimensionale Aufnahmen des Auges bildlich dargestellt und ausgewertet werden. Exkl.: Augenuntersuchung"
            },
            {
              "code" : "DG020109",
              "display" : "PET-Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer nuklearmedizinischen Untersuchung, welche zum größten Teil im Rahmen der Tumordiagnostik eingesetzt wird. Die Stoffwechselvorgänge im Gewebe werden bildlich dargestellt und ausgewertet. Es handelt sich um eine Positronen-Emissions-Tomographie. Exkl.: CT-Befund, SPECT-Befund, Szintigraphie"
            },
            {
              "code" : "DG020110",
              "display" : "Röntgenbefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer radiologischen Untersuchung bei der Körperstrukturen wie Knochen, Gefäße und innere Organe mit Hilfe eines Röntgen-Gerätes durchleuchtet, bildlich dargestellt und ausgewertet werden. Exkl.: Mammographie, Angiographiebefund"
            },
            {
              "code" : "DG020111",
              "display" : "Sonographiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung mittels Ultraschall, bei der organisches Gewebe bildlich dargestellt und ausgewertet werden. Exkl.: Echokardiographie, Inkl.: Doppler-, Duplexsonographie, Endosonographie"
            },
            {
              "code" : "DG020112",
              "display" : "SPECT-Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer nuklearmedizinischen Untersuchung, welche zum größten Teil im Rahmen der Tumordiagnostik eingesetzt wird. Die Stoffwechselvorgänge im Gewebe werden grafisch dargestellt und ausgewertet. Es handelt sich um eine Einzelphotonen-Emissionscomputertomographie. Exkl.: CT-Befund, PET-Befund, Szintigraphie"
            },
            {
              "code" : "DG020113",
              "display" : "Szintigraphiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer nuklearmedizinischen Untersuchung, mittels Gabe einer radioaktiven Substanz, bei welcher Entzündungen oder Tumore in Organen und Knochen bildlich dargestellt und ausgewertet werden. Exkl.: PET-Befund, SPECT-Befund"
            },
            {
              "code" : "DG020114",
              "display" : "Mammographiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer radiologischen Untersuchung bei der mittels Röntgenstrahlen das Brustgewebe durchleuchtet, bildlich dargestellt und ausgewertet wird. Exkl.: Röntgenbefund"
            },
            {
              "code" : "DG020115",
              "display" : "Checkliste bildgebende Diagnostik",
              "definition" : "Die Dokumentation beinhaltet Angaben über Voraussetzungen, den Ablauf oder erforderliche bildgebende Diagnostiken. Erfolgte Durchführungen werden gekennzeichnet."
            },
            {
              "code" : "DG020199",
              "display" : "Sonstige Dokumentation bildgebende Diagnostik",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Kapillarmikroskopie"
            }
          ]
        },
        {
          "code" : "DG0601",
          "display" : "Funktionsdiagnostiken",
          "concept" : [
            {
              "code" : "DG060101",
              "display" : "Anforderung Funktionsdiagnostik",
              "definition" : "Die Dokumentation beinhaltet die Anforderung oder Anmeldung von Diagnostiken ohne bildgebende Darstellung."
            },
            {
              "code" : "DG060102",
              "display" : "Audiometriebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse über die Messung der Funktionalität des Gehörs."
            },
            {
              "code" : "DG060103",
              "display" : "Befund evozierter Potentiale",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von neurophysiologischen Untersuchungen, bei der Veränderungen der elektrischen Aktivität von Nerven, Rückenmark oder Gehirn dargestellt und ausgewertet werden. z.B.: VEP, AEP, SEP"
            },
            {
              "code" : "DG060104",
              "display" : "Blutdruckprotokoll",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von Messungen des arteriellen und venösen Drucks in den Blutgefäßen."
            },
            {
              "code" : "DG060105",
              "display" : "CTG-Ausdruck",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von Messungen der Herztöne des ungeborenen Kindes sowie die Wehentätigkeit der Mutter."
            },
            {
              "code" : "DG060106",
              "display" : "Dokumentationsbogen Feststellung Hirntod",
              "definition" : "Die Dokumentation beinhaltet Angaben zu den Voraussetzungen, den klinischen Symptomen und dem Irreversibillitätsnachweis zur Feststellung des Hirnfunktionsausfalls."
            },
            {
              "code" : "DG060107",
              "display" : "Dokumentationsbogen Herzschrittmacherkontrolle",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Nachsorgeuntersuchung nach dem Einsetzen eines Herzschrittmacherimplantats."
            },
            {
              "code" : "DG060108",
              "display" : "Dokumentationsbogen Lungenfunktionsprüfung",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung zur Feststellung der Leistungsfähigkeit der Lunge. Inkl.: Bodyplethysmographie, Spirometrie"
            },
            {
              "code" : "DG060109",
              "display" : "EEG-Auswertung",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse sowie die visuelle Darstellung der Aufzeichnung und Messung der elektrischen Ströme des Gehirns."
            },
            {
              "code" : "DG060110",
              "display" : "EMG-Befund",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse sowie die visuelle Darstellung der Aufzeichnung und Messung der elektrischen Muskelaktivität."
            },
            {
              "code" : "DG060111",
              "display" : "EKG-Auswertung",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse sowie die visuelle Darstellung der Aufzeichnung und Messung der elektrischen Aktivität des Herzens. Exkl.: Ergometriebefund, Belastungs-EKG"
            },
            {
              "code" : "DG060112",
              "display" : "Manometriebefund",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse und die visuelle Darstellung einer physikalischen Druckmessung von Hohlorganen. Exkl.: Zystometrie, Rhinomanometrie"
            },
            {
              "code" : "DG060113",
              "display" : "Messungsprotokoll Augeninnendruck",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse der Messung des Augeninnendrucks (Tonometrie) mittels Applationstonometer."
            },
            {
              "code" : "DG060114",
              "display" : "Neurographiebefund",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse der Messung der Nervenleitgeschwindigkeit peripherer Nerven. Dazu zählen Nerven, die Muskeln versorgen sowie Nerven für Sinnesempfindungen."
            },
            {
              "code" : "DG060115",
              "display" : "Rhinometriebefund",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse der Darstellung des Nasenquerschnittes um Engstellen zu lokalisieren und zu messen."
            },
            {
              "code" : "DG060116",
              "display" : "Schlaflabordokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse und Auswertung des Schlafverhaltens."
            },
            {
              "code" : "DG060117",
              "display" : "Schluckuntersuchung",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse einer Prüfung des Schluckverhaltens."
            },
            {
              "code" : "DG060118",
              "display" : "Checkliste Funktionsdiagnostik",
              "definition" : "Die Dokumentation beinhaltet Angaben über Voraussetzungen, den Ablauf oder erforderliche funktionelle Diagnostiken. Erfolgte Durchführungen werden gekennzeichnet."
            },
            {
              "code" : "DG060119",
              "display" : "Ergometriebefund",
              "definition" : "Die Dokumentation beinhaltet die Messergebnisse mittels EKG, wo unter körperlicher Belastung die Leistungsfähigkeit des Herz - Kreislaufsystem getestet wird. Inkl.: Spiroergometrie Exkl.: EKG-Auswertung Inkl.: Belastungs-EKG"
            },
            {
              "code" : "DG060120",
              "display" : "Kipptischuntersuchung",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse eines medizinischen Verfahrens, dass zur Klärung von Synkopen dient, um die Veränderung von Blutdruck und Puls zu testen."
            },
            {
              "code" : "DG060121",
              "display" : "Augenuntersuchung",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse von diversen Untersuchungen des Auges. Exkl.: OCT-Befund, Messungsprotokoll Augeninnendruck"
            },
            {
              "code" : "DG060122",
              "display" : "Dokumentationsbogen ICD-Kontrolle",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Nachsorgeuntersuchung nach dem Einsetzen eines Defibrillators auf seine Funktion."
            },
            {
              "code" : "DG060123",
              "display" : "Zystometrie",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung, bei der Druck und Volumen der Harnblase gemessen wird."
            },
            {
              "code" : "DG060124",
              "display" : "Uroflowmetrie",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer urologischen Untersuchungsmethode, bei der eine Messung der Menge und Dauer des Harnflusses vorgenommen wird. Inkl.: Urodynamische Untersuchung"
            },
            {
              "code" : "DG060199",
              "display" : "Sonstige Dokumentation Funktionsdiagnostik",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: PH Metrie, CNG-Analyse"
            }
          ]
        },
        {
          "code" : "DG0602",
          "display" : "Funktionstests",
          "concept" : [
            {
              "code" : "DG060201",
              "display" : "Schellong Test",
              "definition" : "Die Dokumentation beinhaltet Messergebnisse von Herzfrequenz und Blutdruck nach dem Wechsel aus der liegenden Position in den Stand. Inkl.: Anforderung Schellong Test"
            },
            {
              "code" : "DG060202",
              "display" : "H2 Atemtest",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung der Atemgase zur Diagnostik von Magen-Darm Erkrankungen. Inkl.: Anforderung H2 Atemtest, C13 Atemtest"
            },
            {
              "code" : "DG060203",
              "display" : "Allergietest",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse eines Verfahrens, mit dem man natürliche Abwehrreaktionen des Körpers nachweisen kann. Inkl.: Anforderung Allergietest"
            },
            {
              "code" : "DG060204",
              "display" : "Zahlenverbindungstest",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse eines Tests auf kognitive Fähigkeiten beim Verbinden von Zahlen in einer bestimmten Reihenfolge. Dabei werden Dauer und Richtigkeit ausgewertet. Inkl.: Trail Making Test, Anforderung Zahlenverbindungstest"
            },
            {
              "code" : "DG060205",
              "display" : "6-Minuten-Gehtest",
              "definition" : "Die Dokumentation beinhaltet Messwerte der Herzfrequenz, des Blutdrucks und der Sauerstoffversorgung des Blutes vor und nach dem Zurücklegen einer Strecke. Inkl.: Gehstreckentest, Anforderung 6-Minuten-Gehtest"
            },
            {
              "code" : "DG060209",
              "display" : "Sonstige Funktionstests",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "DG060299",
              "display" : "Sonstiger Funktionstest",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Kopfimpulstest, Riechtest, Gehstreckentest"
            }
          ]
        }
      ]
    },
    {
      "code" : "ED",
      "display" : "Elektronische Dokumentation",
      "concept" : [
        {
          "code" : "ED0101",
          "display" : "Audiodokumentation",
          "concept" : [
            {
              "code" : "ED010199",
              "display" : "Sonstige Audiodokumentation",
              "definition" : "Die Dokumentation beinhaltet ausschließlich Audiodokumentation."
            }
          ]
        },
        {
          "code" : "ED0201",
          "display" : "Bilddokumentation",
          "concept" : [
            {
              "code" : "ED020101",
              "display" : "Fotodokumentation Operation",
              "definition" : "Die Dokumentation beinhaltet die digitale direkte Fotodokumentation, die ohne Medienbruch zwischen Anwendungssystemen übertragen werden - Schwerpunkt: Operation. Exkl. OP-Bilddokumentation, Fotodokumentation Wunden"
            },
            {
              "code" : "ED020102",
              "display" : "Fotodokumentation Dermatologie",
              "definition" : "Die Dokumentation beinhaltet die digitale direkte Fotodokumentation, die ohne Medienbruch zwischen Anwendungssystemen übertragen werden - Schwerpunkt: Dermatologie. Exkl. Fotodokumentation Wunden, Fotodokumentation Dekubitus"
            },
            {
              "code" : "ED020103",
              "display" : "Fotodokumentation Diagnostik",
              "definition" : "Die Dokumentation beinhaltet die digitale direkte Fotodokumentation, die ohne Medienbruch zwischen Anwendungssystemen übertragen wird - Schwerpunkt: Diagnostik"
            },
            {
              "code" : "ED020104",
              "display" : "Videodokumentation Operation",
              "definition" : "Die Dokumentation beinhaltet die digitale direkte Videodokumentation - Schwerpunkt: Operation"
            },
            {
              "code" : "ED020199",
              "display" : "Foto-/Videodokumentation Sonstige",
              "definition" : "Die Dokumentation beinhaltet die digitale direkte Foto- oder Videodokumentation, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Beispiel: Anforderung Fotolabor"
            }
          ]
        },
        {
          "code" : "ED1101",
          "display" : "KIS",
          "concept" : [
            {
              "code" : "ED110101",
              "display" : "Behandlungspfad",
              "definition" : "Die Dokumentation beinhaltet den im KIS definierten Behandlungsablauf. Elektronische Dokumentation. Ggf. informativer Ausdruck in Papierkrankenakte."
            },
            {
              "code" : "ED110102",
              "display" : "Notfalldatenmanagement (NFDM)",
              "definition" : "Die Dokumentation beinhaltet für den Notfall eine Übersicht über Vorerkrankungen, chronische Erkrankungen, Dauermedikation oder Allergien. Inkl.: Kontaktdaten behandelnde Ärzte, Angehörige, Persönliche Erklärungen - wie Patientenverfügung, Vorsorgevollmacht. Detailinformationen: gematik (2021): https://fachportal.gematik.de/anwendungen/notfalldatenmanagement. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110103",
              "display" : "Medikationsplan elektronisch (eMP)",
              "definition" : "Der eMP enthält einen strukturierten Überblick darüber, welche Medikamente ein Versicherter aktuell einnimmt. Darüber hinaus enthält der eMP medikationsrelevante Informationen, die wichtig sind, um unerwünschte Wechselwirkungen zu vermeiden, bspw. zu Allergien. Exkl.: Medikamentenplan. Detailinformationen: gematik (2021): https://fachportal.gematik.de/anwendungen/elektronischer-medikationsplan. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110104",
              "display" : "eArztbrief",
              "definition" : "Die Dokumentation beinhaltet die Zusammenfassung einer ambulanten ärztlichen, psychotherapeutischen Behandlung. Exkl. Arztberichte der Unterklasse AD0101 Detailinformationen: KBV (2022): https://www.kbv.de/html/earztbrief.php. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110105",
              "display" : "eImpfpass",
              "definition" : "Die Dokumentation beinhaltet alle durchgeführten Impfungen. Detailinformationen: KBV (2022): https://mio.kbv.de/display/IM. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110106",
              "display" : "eZahnärztliches Bonusheft",
              "definition" : "Die Dokumentation beeinhaltet Informationen zu zahnärztlichen Kontrolluntersuchungen.  Detailinformationen: KBV (2021): https://mio.kbv.de/display/ZB. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110107",
              "display" : "eArbeitsunfähigkeitsbescheinigung",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Arbeitsunfähigkeit.  Exkl.: Arbeitsunfähigkeitsbescheinigung (papierbasiert) Detailinformationen: KBV (2022): https://www.kbv.de/html/e-au.php. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110108",
              "display" : "eRezept",
              "definition" : "Die Dokumentation beinhaltet die ärztliche Verordnung von Arznei- oder Heilmitteln. Das elektronische Rezept wird seit Mitte 2021 stufenweise eingeführt. Exkl.: Rezept (KBV Muster 16) Detailinformationen: gematik (2021): https://fachportal.gematik.de/anwendungen/elektronisches-rezept. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110109",
              "display" : "Pflegebericht",
              "definition" : "Nicht mehr zu verwenden! Ab KDL-2024 nicht mehr gültig, da keine Unterscheidung zwischen papierbasierten und elektronischen Pflegeberichten erforderlich ist. Pflegeberichte sind mit der KDL VL160105 zu kodieren.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "ED110110",
              "display" : "eDMP",
              "definition" : "Die Dokumentation beeinhaltet den strukturierten Statusbericht der Behandlung chronisch Kranker (= Disease Management Program - DMP). Detailinformationen: KBV (2022): https://www.kbv.de/html/e-dmp.php. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110111",
              "display" : "eMutterpass",
              "definition" : "Die Dokumentation beinhaltet die Ergebnisse der Vorsorgeuntersuchungen während der Schwangerschaft und nach der Entbindung. Exkl.: Mutterpass (Kopie)  Detailinformationen: KBV (2021): https://mio.kbv.de/display/MP. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110112",
              "display" : "KH-Entlassbrief",
              "definition" : "Die Dokumentation beinhaltet Informationen zum Anlass der Behandlung, zu diagnostischen und therapeutischen Maßnahmen. Die Informationen umfassen weiterhin den klinischen Verlauf, die Medikation sowie Angaben zu nachstationären Maßnahmen. Exkl: Arztberichte der Unterklasse AD0101. Hinweis: Spezifikation ist in Planung. Detailinformationen: KBV (2021): https://mio.kbv.de/display/khe. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110113",
              "display" : "U-Heft Untersuchungen",
              "definition" : "Die Dokumentation beeinhaltet die Ergebnisse von Früherkennungsuntersuchungen bei Kindern. Es umfasst Informationen beginnend mit der Geburt bis zum Alter von etwa fünf Jahren. Inkl. MIO Perzentilkurven Detailinformationen: KBV (2021): https://mio.kbv.de/display/UH. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110114",
              "display" : "U-Heft Teilnahmekarte",
              "definition" : "Die Dokumentation beinhaltet das Datum der U-Untersuchung, an der teilgenommen wurde. Es entspricht einer Verlaufsdokumentation und wird als Gesamtdokumente in der ePA visualisiert. Detailinformationen: KBV (2021): https://mio.kbv.de/pages/viewpage.action?pageId=99746571#id-2.Teilnahmekarte-Teilnahmekarte. Zugegriffen: 28.02.2022"
            },
            {
              "code" : "ED110115",
              "display" : "U-Heft Elternnotiz",
              "definition" : "Die Dokumentation beinhaltet narrative Notizen der Eltern zum Verhalten ihres Kindes. Detailinformationen: KBV (2021): https://mio.kbv.de/display/UH1X0X1/1.8+Elternnotiz. Zugegriffen: 28.02.2022"
            },
            {
              "code" : "ED110116",
              "display" : "Überleitungsbogen",
              "definition" : "Die Dokumentation beeinhaltet pflege- und versorgungsrelevante Informationen über zu pflegende Personen. Exkl: Pflegeüberleitungsbogen (papierbasiert) Detailinformationen: KBV (2022): https://mio.kbv.de/display/ULB. Zugegriffen: 18.02.2022"
            },
            {
              "code" : "ED110199",
              "display" : "Sonstige Dokumentation KIS",
              "definition" : "Die Dokumentation beinhaltet alle elektronischen Daten und Dokumententypen die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann, jedoch elektronisch direkt ausgetauscht wird."
            }
          ]
        },
        {
          "code" : "ED1901",
          "display" : "Schriftverkehr elektronisch",
          "concept" : [
            {
              "code" : "ED190101",
              "display" : "E-Mail Befundauskunft",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per E-Mail - direkt elektronisch oder ausgedruckt in Papierkrankenakte. Schwerpunkt: Befundergebnisse"
            },
            {
              "code" : "ED190102",
              "display" : "E-Mail Juristische Beweissicherung",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per E-Mail - direkt elektronisch oder ausgedruckt in Papierkrankenakte. Schwerpunkt: Juristische Beweissicherung"
            },
            {
              "code" : "ED190103",
              "display" : "E-Mail Arztauskunft",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per E-Mail - direkt elektronisch oder ausgedruckt in Papierkrankenakte.  Schwerpunkt: Arztauskunft ohne Befundergebnisse"
            },
            {
              "code" : "ED190104",
              "display" : "E-Mail Sonstige",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per E-Mail - direkt elektronisch oder ausgedruckt in Papierkrankenakte - die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            },
            {
              "code" : "ED190105",
              "display" : "Fax Befundauskunft",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per Fax - direkt elektronisch oder ausgedruckt in Papierkrankenakte. Inhaltlicher Schwerpunkt: Befundergebnisse"
            },
            {
              "code" : "ED190106",
              "display" : "Fax Juristische Beweissicherung",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per Fax - direkt elektronisch oder ausgedruckt in Papierkrankenakte. Schwerpunkt: Juristische Beweissicherung"
            },
            {
              "code" : "ED190107",
              "display" : "Fax Arztauskunft",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per Fax - direkt elektronisch oder ausgedruckt in Papierkrankenakte. Schwerpunkt: Arztauskunft ohne Befundergebnisse"
            },
            {
              "code" : "ED190108",
              "display" : "Fax Sonstige",
              "definition" : "Die Dokumentation beinhaltet den Informationsaustausch per Fax - direkt elektronisch oder ausgedruckt in Papierkrankenakte - die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            },
            {
              "code" : "ED190199",
              "display" : "Sonstiger elektronischer Schriftverkehr",
              "definition" : "Die Dokumentation beinhaltet den rein elektronischen Schriftverkehr, der nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        }
      ]
    },
    {
      "code" : "LB",
      "display" : "Labor",
      "concept" : [
        {
          "code" : "LB0201",
          "display" : "Blut",
          "concept" : [
            {
              "code" : "LB020101",
              "display" : "Blutgasanalyse",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse zur Gasverteilung im Blut."
            },
            {
              "code" : "LB020102",
              "display" : "Blutkulturenbefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer mikrobiologischen Untersuchung des Blutes, um Erreger nachzuweisen oder auszuschließen. Exkl.: Mikrobiologiebefund, Urinbefund, Virologiebefund"
            },
            {
              "code" : "LB020103",
              "display" : "Herstellungs- und Prüfprotokoll von Blut und Blutprodukten",
              "definition" : "Die Dokumentation beinhaltet Angaben im Rahmen der Herstellung von Blut und Blutprodukten. Mindestinhalte sind: Datum, verantwortliche Person, Art des Blutes bzw. Blutproduktes"
            },
            {
              "code" : "LB020104",
              "display" : "Serologischer Befund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung, bei der das Blut auf Antigene und Antikörper getestet wird."
            },
            {
              "code" : "LB020199",
              "display" : "Sonstige Dokumentation Blut",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Aphareseprotokoll, Plasmaphereseprotokoll, Photophereseprotokoll"
            }
          ]
        },
        {
          "code" : "LB1201",
          "display" : "Laborbefunde",
          "concept" : [
            {
              "code" : "LB120101",
              "display" : "Glukosetoleranztestprotokoll",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse, wie gut der Körper eine festgelegte Menge Zucker verarbeiten kann."
            },
            {
              "code" : "LB120102",
              "display" : "Laborbefund extern",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von Untersuchungen verschiedenster Materialien durch ein Fremdlabor/Praxis. Inkl.: Kumulativbefund, Vorbefund. Exkl.: Mikrobiologiebefund, Serologischer Befund;  Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL LB120107 (Laborbefund) möglich."
            },
            {
              "code" : "LB120103",
              "display" : "Laborbefund intern",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von Untersuchungen verschiedenster Materialien durch ein hauseigenes Labor. Inkl.: Kumulativbefund, Vorbefund. Exkl.: Laborbefund extern, Mikrobiologiebefund, Serologischer Befund; Hinw.: Diese KDL-Dokumentenklasse wird ab 1. Januar 2026 obsolet. Die Abbildung ist ab sofort mit der KDL LB120107 (Laborbefund) möglich."
            },
            {
              "code" : "LB120104",
              "display" : "Anforderung Labor",
              "definition" : "Die Dokumentation beinhaltet die Anforderung einer Diagnostik zur  Untersuchungen verschiedenster Materialien durch ein Labor auf standardisiertem KBV Formular (10A). Exkl.: Histologieanforderung, Zytologieanforderung, Molekularpathologieanforderung, Überweisungsschein Labor"
            },
            {
              "code" : "LB120105",
              "display" : "Überweisungsschein Labor",
              "definition" : "Die Dokumentation beinhaltet den Auftrag zur Befundung verschiedenster Materialien durch ein Labor auf standardisiertem KBV Formular (10). Exkl.: Anforderung Labor, Histologieanforderung, Zytologieanforderung, Molekularpathologieanforderung"
            },
            {
              "code" : "LB120106",
              "display" : "Hämatologisches Speziallabor",
              "definition" : "Die Dokumentation beinhaltet Informationen zu spezieller hämatologischer Diagnostik, wie bspw. Zytologie, Durchflusszytometrie, Molekulare Diagnostik, Zytogenetik."
            },
            {
              "code" : "LB120107",
              "display" : "Laborbefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse von Untersuchungen verschiedenster Materialien."
            },
            {
              "code" : "LB120199",
              "display" : "Sonstiger Laborbefund",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "LB1301",
          "display" : "Mikrobiologie",
          "concept" : [
            {
              "code" : "LB130101",
              "display" : "Mikrobiologiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse der Untersuchung von Proben auf Bakterien, Pilze oder Viren und dessen Empfindlichkeit gegenüber Antiinfektiva. Exkl.: Urinbefund, Virologiebefund, Blutkulturenbefund"
            },
            {
              "code" : "LB130102",
              "display" : "Urinbefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse der Urin-Untersuchung, um Erkrankungen der Harnorgane und Stoffwechselstörungen festzustellen. Exkl.: Mikrobiologiebefund, Laborbefund intern/extern"
            }
          ]
        },
        {
          "code" : "LB2201",
          "display" : "Virologie",
          "concept" : [
            {
              "code" : "LB220101",
              "display" : "Befund über positive Infektionsmarker",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "LB220102",
              "display" : "Virologiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse aus der Bestimmung von Viren in Untersuchungsmaterialien. Exkl.: Mikrobiologiebefund, Blutkulturenbefund"
            }
          ]
        }
      ]
    },
    {
      "code" : "OP",
      "display" : "Operation",
      "concept" : [
        {
          "code" : "OP0101",
          "display" : "Anästhesie",
          "concept" : [
            {
              "code" : "OP010101",
              "display" : "Intraoperative Anästhesiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Schmerzausschaltung und Bewusstseinslage während eines Eingriffs, Operation. Exkl.: Aufwachraumprotokoll"
            },
            {
              "code" : "OP010102",
              "display" : "Aufwachraumprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Aufwachphase nach einem Eingriff, Operation."
            },
            {
              "code" : "OP010103",
              "display" : "Checkliste Anästhesie",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Voraussetzungen für die Durchführung einer Anästhesie."
            },
            {
              "code" : "OP010104",
              "display" : "Präoperative Anästhesiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die für die durchzuführende Anästhesie erforderlich sind. Dazu zählen bspw. Informationen zu Vorerkrankungen und Vormedikation, Anästhesiologische Untersuchungsbefunde, Allergien, Anästhesiologische Scores, Anordnungen Prämedikation. Inkl.: Präoperative Visite"
            },
            {
              "code" : "OP010105",
              "display" : "Postoperative Anästhesiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die sich auf die postoperative anästhesiologische Betreuung beziehen. Inkl. Aufwachraumprotokoll. Hinw.: Erfolgt die Überwachung auf Normalstation, ist die KDL VL160110 (Überwachungsprotokoll) zu verwenden."
            },
            {
              "code" : "OP010199",
              "display" : "Sonstige Anästhesiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Anästhesieausweis, Katheterprotokoll Anästhesie, PCEA Protokoll"
            }
          ]
        },
        {
          "code" : "OP1501",
          "display" : "OP-Dokumente",
          "concept" : [
            {
              "code" : "OP150101",
              "display" : "Chargendokumentation",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über verwendete Medizinprodukte und Arzneimittel während eines Eingriffes/Untersuchung. Exkl.: OP-Zählprotokoll"
            },
            {
              "code" : "OP150102",
              "display" : "OP-Anmeldungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Anmeldung eines Patienten für einen operativen Eingriff."
            },
            {
              "code" : "OP150103",
              "display" : "OP-Bericht",
              "definition" : "Die Dokumentation beinhaltet die  Zusammenfassung des Operationsverlaufes durch den Arzt."
            },
            {
              "code" : "OP150104",
              "display" : "OP-Bilddokumentation",
              "definition" : "Die Dokumentation beinhaltet ausschließlich die bildliche Dokumentation, die während eines operativen Eingriffes entstanden ist. Exkl. Fotodokumentation Wunden, Fotodokumentation Dekubitus"
            },
            {
              "code" : "OP150105",
              "display" : "OP-Checkliste",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Voraussetzungen und den Ablauf eines operativen Eingriffes."
            },
            {
              "code" : "OP150106",
              "display" : "OP-Protokoll",
              "definition" : "Die Dokumentation beinhaltet zusätzliche Angaben im Rahmen einer Operation. Inhalte sind u. a. OP-Team, Schnitt-Naht-Zeit, Materialverbrauch."
            },
            {
              "code" : "OP150107",
              "display" : "Postoperative Verordnung",
              "definition" : "Die Dokumentation beinhaltet Anweisungen für den weiteren Behandlungsverlauf nach einem operativen Eingriff."
            },
            {
              "code" : "OP150108",
              "display" : "OP-Zählprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Vollzähligkeit des verwendeten Materials während einer Operation. Exkl.: Chargendokumentation"
            },
            {
              "code" : "OP150109",
              "display" : "Dokumentation ambulantes Operieren",
              "definition" : "Die Dokumentation beinhaltet alle Formulare im Bereich des ambulanten Operierens, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            },
            {
              "code" : "OP150199",
              "display" : "Sonstige OP-Dokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Begleitschein für Explantate, OP Begleitzettel, OP Übergabeprotokoll, OP Vorbereitungsbogen, HLM Protokoll"
            }
          ]
        },
        {
          "code" : "OP2001",
          "display" : "Transplantationsdokumente",
          "concept" : [
            {
              "code" : "OP200101",
              "display" : "Transplantationsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Nachweise über die Transplantation von Gewebe, Organen oder Körperteilen."
            },
            {
              "code" : "OP200102",
              "display" : "Spenderdokument",
              "definition" : "Die Dokumentation beinhaltet alle relevanten Angaben zum Spender für eine Transplantation. Exkl.: Blutspendeprotokoll"
            },
            {
              "code" : "OP200199",
              "display" : "Sonstige Transplantationsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann.  Inkl.: Anmeldung zur Transplantation, Transplantationsbegleitschein, Checkliste Transplantation"
            }
          ]
        }
      ]
    },
    {
      "code" : "PT",
      "display" : "Pathologie",
      "concept" : [
        {
          "code" : "PT0801",
          "display" : "Histopathologie",
          "concept" : [
            {
              "code" : "PT080101",
              "display" : "Histologieanforderung",
              "definition" : "Die Dokumentation beinhaltet die Anforderung einer Untersuchung zur Bestimmung von Veränderungen anhand von Gewebeproben. Inkl.: Obduktionsantrag Exkl.: Laboranforderung, Zytologieanforderung, Molekularpathologieanforderung"
            },
            {
              "code" : "PT080102",
              "display" : "Histologiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung zur Bestimmung von Veränderungen anhand von Gewebeproben."
            }
          ]
        },
        {
          "code" : "PT1301",
          "display" : "Molekularpathologie",
          "concept" : [
            {
              "code" : "PT130101",
              "display" : "Molekularpathologieanforderung",
              "definition" : "Die Dokumentation beinhaltet die Anforderung einer Untersuchung zur Bestimmung von Veränderungen der Erbinformation. Exkl.: Histologieanforderung, Anforderung Labor, Zytologieanforderung"
            },
            {
              "code" : "PT130102",
              "display" : "Molekularpathologiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung der Erbinformationen auf Veränderungen. Inkl.: Zytogenetikbefund"
            }
          ]
        },
        {
          "code" : "PT2301",
          "display" : "Weitere Pathologiedokumentation",
          "concept" : [
            {
              "code" : "PT230199",
              "display" : "Sonstige pathologische Dokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL der Unterklassen PT0801, PT1301, PT2601 abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "PT2601",
          "display" : "Zytopathologie",
          "concept" : [
            {
              "code" : "PT260101",
              "display" : "Zytologieanforderung",
              "definition" : "Die Dokumentation beinhaltet die Anforderung einer Untersuchung zur Bestimmung von Veränderungen anhand von Zellproben. Exkl.:  Histologieanforderung, Laboranforderung, Molekularpathologieanforderung"
            },
            {
              "code" : "PT260102",
              "display" : "Zytologiebefund",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse einer Untersuchung zur Bestimmung von Veränderungen anhand von Zellproben."
            }
          ]
        }
      ]
    },
    {
      "code" : "SD",
      "display" : "Spezielle Dokumentation",
      "concept" : [
        {
          "code" : "SD0701",
          "display" : "Geburtendokumente",
          "concept" : [
            {
              "code" : "SD070101",
              "display" : "Geburtenbericht",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Ablauf der Entbindung und unmittelbar danach, mit Angaben zur Mutter und zum Kind. Die Erfassung erfolgt nicht standardisiert als Freitext. Inkl.: Geburtenprotokoll"
            },
            {
              "code" : "SD070102",
              "display" : "Geburtenprotokoll",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "SD070103",
              "display" : "Geburtenverlaufskurve",
              "definition" : "Die Dokumentation beinhaltet Angaben über den Zeitraum der Entbindung. Vitalzeichen werden als Kurve dargestellt. Exkl.: Pflegekurve, Säuglingskurve"
            },
            {
              "code" : "SD070104",
              "display" : "Neugeborenenscreening",
              "definition" : "Die Dokumentation beinhaltet Untersuchungen vom Neugeborenen. Dazu gehören neben Laboruntersuchungen von Stoffwechselerkrankungen auch Hörtest und Sonographie der Hüften. Inkl.: Apgar"
            },
            {
              "code" : "SD070105",
              "display" : "Partogramm",
              "definition" : "Die Dokumentation beinhaltet die graphische Darstellung zur Geburtensituation und der Eröffnung des Muttermundes bei Entbindung."
            },
            {
              "code" : "SD070106",
              "display" : "Wiegekarte",
              "definition" : "Die Dokumentation beinhaltet die Kontrolle des Geburts- und Verlaufsgewichtes im 1. Lebensjahr."
            },
            {
              "code" : "SD070107",
              "display" : "Neugeborenendokumentationsbogen",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "SD070108",
              "display" : "Säuglingskurve",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Erfassung von Vitalzeichen, Trinkverhalten, Laborwerten und Pflegemaßnahmen des Säuglings/Neugeborenen. Vitalzeichen werden als Kurve dargestellt. Exkl.: Pflegekurve, Intensivkurve, Inkl.: Neugeborenendokumentationsbogen"
            },
            {
              "code" : "SD070109",
              "display" : "Geburtenbogen",
              "definition" : "Die Dokumentation beinhaltet standardisierte Angaben, die im Rahmen einer Entbindung erhoben werden. Exkl.: Geburtenverlaufskurve, Geburtenbericht"
            },
            {
              "code" : "SD070110",
              "display" : "Perzentilkurve",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Verlauf von Gewicht, Länge und Kopfumfang. Exkl.: Messblatt"
            },
            {
              "code" : "SD070111",
              "display" : "Entnahme Nabelschnurblut",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "SD070112",
              "display" : "Datenblatt für den Pädiater",
              "definition" : "Die Dokumentation beinhaltet klinische sowie administrative Angaben des Neugeborenen wie Geburtenbuch Nr., Geburtsdauer, Geburtsgewicht, Apgar und Angaben zu Vater und Mutter. Die Daten werden auf einem standardisierten Formular erfasst. Exkl.: Geburtenbogen"
            },
            {
              "code" : "SD070199",
              "display" : "Sonstige Geburtendokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.:Dokumentationsbogen Schulterdystokie, Geburtsplanung,  Still- /Ernährungsprotokoll, Entnahme Nabelschnurblut"
            }
          ]
        },
        {
          "code" : "SD0702",
          "display" : "Geriatrische Dokumente",
          "concept" : [
            {
              "code" : "SD070201",
              "display" : "Barthel Index",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Ermittlung der eventuell benötigten Hilfestellung im Alltag. Die Auswertung erfolgt durch ein Punktesystem."
            },
            {
              "code" : "SD070202",
              "display" : "Dem Tect",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Untersuchung von kognitiven Fähigkeiten, zur Früherkennung von Demenz. Die Auswertung erfolgt durch ein Punktesystem."
            },
            {
              "code" : "SD070203",
              "display" : "ISAR Screening",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "SD070204",
              "display" : "Sturzrisikoerfassungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Ermittlung der Sturzgefahr und Festlegung vorbeugender Maßnahmen. Die Auswertung erfolgt durch ein Punktesystem. Exkl.: Mobilitätstest nach Tinetti"
            },
            {
              "code" : "SD070205",
              "display" : "Geriatrische Depressionsskala",
              "definition" : "Die Dokumentation beinhaltet Fragen, um Hinweise auf eine evtl. vorhandene Altersdepression zu ermitteln. Die Auswertung erfolgt durch ein Punktesystem. Exkl.: Dokumentation Depression"
            },
            {
              "code" : "SD070206",
              "display" : "Geriatrische Assessmentdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Erfassung von erhaltenen Funktionen sowie Problemen im Alter. Exkl.: Barthel-Index, Tinetti-Test, GDS, Dem Tect, Uhrentest"
            },
            {
              "code" : "SD070207",
              "display" : "Mobilitätstest nach Tinetti",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Messung des Sturzrisikos im Alter, nach festen Kriterien. Bewertet werden Gleichgewichtssinn und Gangbild. Die Auswertung erfolgt durch ein Punktesystem. Exkl.: Sturzrisikoerfassungsbogen"
            },
            {
              "code" : "SD070208",
              "display" : "Timed Up and Go Test",
              "definition" : "Die Dokumentation beinhaltet die Erhebung und/oder die Beurteilung der Fortbeweglichkeit in einem bestimmten Zeitraum. Exkl.: Sturzrisikoerfassung, Mobilitätstest nach Tinetti"
            },
            {
              "code" : "SD070299",
              "display" : "Sonstiges geriatrisches Dokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Geriatrisches Screening"
            }
          ]
        },
        {
          "code" : "SD1101",
          "display" : "Komplexbehandlungen",
          "concept" : [
            {
              "code" : "SD110101",
              "display" : "Geriatrische Komplexbehandlungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet eine ganzheitliche interdisziplinäre geriatrische Beurteilung mit Festlegung von Maßnahmen im Behandlungsverlauf. Exkl.: Teambesprechungsprotokoll"
            },
            {
              "code" : "SD110102",
              "display" : "Intensivmedizinische Komplexbehandlungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet alle Angaben zu intensivmedizinischen Scores (bspw. TISS10 und SAPS II)."
            },
            {
              "code" : "SD110103",
              "display" : "MRE/Nicht-MRE Komplexbehandlung",
              "definition" : "Die Dokumentation beinhaltet Angaben über den Mehraufwand bei einer Infektion durch multiresistente Keime. Exkl.: Teambespechungsprotokoll, Isolationsprotokoll"
            },
            {
              "code" : "SD110104",
              "display" : "Neurologische Komplexbehandlungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben über  eine mindestens 24-stündige Behandlung auf einer Stroke Unit Station, unter Gewährleistung von ständiger Anwesenheit eines Neurologen, zur kontinuierlichen Betreuung und Überwachung. Inkl.: Stroke Unit Dokumentation"
            },
            {
              "code" : "SD110105",
              "display" : "Palliativmedizinische Komplexbehandlungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet standardisierte Angaben zu Symptom -und Schmerzlinderung bei geringer Lebenserwartung durch eine unheilbare Krankheit. Dies erfolgt unter Beteiligung unterschiedlicher ärztlicher und therapeutischer Fachbereiche. Inkl.: Palliativmedizinisches Basisassessment, Exkl.: Teambesprechungsprotokoll"
            },
            {
              "code" : "SD110106",
              "display" : "PKMS-Dokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Abbildung hochaufwendiger Pflegemaßnahmen in definierten Leistungsbereichen (Standardisierter Pflegekomplexmaßnahmenscore). Exkl.: Teambesprechungsprotokoll"
            },
            {
              "code" : "SD110107",
              "display" : "Dokumentation COVID",
              "definition" : "Die Dokumentation beinhaltet Angaben über den Mehraufwand bei einer Infektion durch ein COVID-Virus. Stehen für diagnostische und/oder therapeutische Maßnahmen im Rahmen der COVID-Behandlung spezifischere KDL-Kodes zur Verfügung, sind diese zu verwenden. Inkl.: Long COVID Dokumentation, Exkl.: Dokumentation Meldepflicht"
            },
            {
              "code" : "SD110199",
              "display" : "Sonstige Komplexbehandlungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Multimodale Komplexbehandlung bei Diabetes mellitus, Rheumatologische Komplexbehandlung, Parkinson Komplexbehandlung Exkl.: Teambesprechungsprotokoll"
            }
          ]
        },
        {
          "code" : "SD1301",
          "display" : "Maßregelvollzug",
          "concept" : [
            {
              "code" : "SD130101",
              "display" : "Vertrag Maßregelvollzug",
              "definition" : "Die Dokumentation beinhaltet Verträge im Rahmen des Maßregelvollzuges. Inkl.: Darlehnsvertrag Exkl.: Behandlungsvertrag, Wahlleistungsvertrag, Heimvertrag"
            },
            {
              "code" : "SD130102",
              "display" : "Antrag Maßregelvollzug",
              "definition" : "Die Dokumentation beinhaltet Anträge im Rahmen des Maßregelvollzuges. Exkl.: Antrag auf Rehabilitation, Antrag auf Betreuung, Antrag auf gesetzliche Unterbringung, Verlängerungsantrag, Antrag auf Psychotherapie, Antrag auf Pflegeeinstufung, Kostenübernahmeantrag, Antrag auf Leistungen der Pflegeversicherung"
            },
            {
              "code" : "SD130103",
              "display" : "Schriftverkehr Maßregelvollzug",
              "definition" : "Die Dokumentation beinhaltet sämtliche Korrespondenzen im Rahmen des Maßregelvollzuges. Exkl.: Schriftverkehr Amtsgericht, Schriftverkehr MDK Arzt, Schriftverkehr Krankenkasse, Schriftverkehr Deutsche Rentenversicherung, Schriftverkehr MDK Kasse"
            },
            {
              "code" : "SD130104",
              "display" : "Einwilligung/Einverständniserklärung Maßregelvollzug",
              "definition" : "Die Dokumentation beinhaltet Einwilligungen und Einverständniserklärungen im Rahmen des Maßregelvollzuges. Exkl.: Schweigepflichtentbindung, Datenschutzerklärung, Einverständniserklärung Abrechnung, Einverständniserklärung Behandlung"
            },
            {
              "code" : "SD130199",
              "display" : "Sonstiges Maßregelvollzugdokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "SD1501",
          "display" : "Onkologische Dokumente",
          "concept" : [
            {
              "code" : "SD150101",
              "display" : "Follow up-Bogen",
              "definition" : "Die Dokumentation beinhaltet Angaben im Rahmen der Nachsorge zur Erfassung der Verlaufskontrolle nach Abschluss der Behandlung."
            },
            {
              "code" : "SD150102",
              "display" : "Meldebogen Krebsregister",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Meldung von Krebserkrankungen an das Krebsregister."
            },
            {
              "code" : "SD150103",
              "display" : "Tumorkonferenzprotokoll",
              "definition" : "Die Dokumentation beinhaltet Ergebnisse des Zusammentreffens von verschiedenen Fachärzten, über die Beratung der weiteren Behandlung von Tumorerkrankungen."
            },
            {
              "code" : "SD150104",
              "display" : "Tumorlokalisationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Erfassung der Tumorposition - überwiegend manuelle Skizze."
            },
            {
              "code" : "SD150199",
              "display" : "Sonstiger onkologischer Dokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Checkliste für Tumorpatienten, Psychoonkologische Basisdokumentation, Tumorverlaufsblatt"
            }
          ]
        },
        {
          "code" : "SD1601",
          "display" : "Dokumente Psychiatrie - Psychotherapie",
          "concept" : [
            {
              "code" : "SD160101",
              "display" : "Patientenaufzeichnungen",
              "definition" : "Die Dokumentation beinhaltet eine persönliche, schriftliche Schilderung von Erlebnissen zur Therapieunterstützung."
            },
            {
              "code" : "SD160102",
              "display" : "Testpsychologische Diagnostik",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Feststellung einer (neuro-)psychischen Erkrankung sowie deren Schweregrad. Die Auswertung erfolgt durch ein Punktesystem."
            },
            {
              "code" : "SD160103",
              "display" : "Psychiatrisch-psychotherapeutische Therapieanordnung",
              "definition" : "Die Dokumentation beinhaltet eine therapeutische Anordnung durch den Arzt zur Behandlung einer psychischen Erkrankung. Inkl.: Therapiepass, Therapieplanung"
            },
            {
              "code" : "SD160104",
              "display" : "Psychiatrisch-psychotherapeutische Therapiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Gesprächsinhalte, die im Rahmen einer psychiatrisch-psychotherapeutischen Therapiesitzung aufgekommen sind."
            },
            {
              "code" : "SD160105",
              "display" : "Psychiatrisch-psychotherapeutischer Verlaufsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben über den Verlauf der psychiatrisch-psychotherapeutischen Behandlung, gekennzeichnet durch Einträge zu verschiedenen Zeitpunkten. Inkl.: Komplexbehandlungsbogen Psych, Exkl.: Spezialtherapeutische Verlaufsdokumentation, Dokumentation Verhaltensanalyse"
            },
            {
              "code" : "SD160106",
              "display" : "Spezialtherapeutische Verlaufsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Planung, Zielsetzung, Durchführung und freitextlichen Verlauf der spezialtherapeutischen Behandlungen. Inkl.: Musiktherapie, Kunsttherapie, Arbeitstherapie, Tanztherapie, Exkl.: Ergotherapie, Logopädie, Physiotherapie"
            },
            {
              "code" : "SD160107",
              "display" : "Therapieeinheiten Ärzte/Psychologen/Spezialtherapeuten",
              "definition" : "Die Dokumentation beinhaltet den Nachweis zur Durchführung der psychiatrisch-psychotherapeutischen Behandlungen (z. B. Gesprächstherapie) einschließlich Zeitangaben (u. a. Musiktherapie)."
            },
            {
              "code" : "SD160108",
              "display" : "1:1 Betreuung/Einzelbetreuung/Psychiatrische Intensivbehandlung",
              "definition" : "Die Dokumentation beinhaltet die Nachweise über die Indikationsstellung, ärztliche und pflegerische Durchführung bei der 1:1-Betreuung, Einzel-/Gruppenbetreuung und Merkmale der Intensivbehandlung (z.B. Sicherungsmaßnahmen). Hinweis: Ergänzende Tagesentgelte, Exkl.: Fixierungsprotokoll"
            },
            {
              "code" : "SD160109",
              "display" : "Checkliste für die Unterbringung psychisch Kranker",
              "definition" : "Die Dokumentation beinhaltet die Prüfung der Einhaltung von Anforderungen im Rahmen PsychKG."
            },
            {
              "code" : "SD160110",
              "display" : "Dokumentation Verhaltensanalyse",
              "definition" : "Die Dokumentation beinhaltet die Planung, Durchführung und Auswertung von Verhaltensanalysen im Rahmen psychiatrisch-psychotherapeutischen Behandlung."
            },
            {
              "code" : "SD160111",
              "display" : "Dokumentation Depression",
              "definition" : "Die Dokumentation beinhaltet die diagnostischen Fragenstellungen, die Einschätzung des Schweregrades im Rahmen psychiatrisch-psychotherapeutischer Behandlung. Inkl.: BDI, Goldberg, Früherkennung, Exkl.: Dem Tect, Geriatrische Depressionsskala"
            },
            {
              "code" : "SD160112",
              "display" : "Dokumentation Stationsäquivalente Behandlung (StäB)",
              "definition" : "Die Dokumentation beinhaltet Nachweise für die Anforderungen entsprechend der Vereinbarung nach § 115d Absatz 2 SGB V Stationsäquivalente psychiatrische Behandlung. Inkl.: Häusliche Situation, Häusliche Behandlungsbedingungen, Eltern-Kind-Behandlung, Darlegung beteiligter Berufsgruppen mit Qualifikation, fachärztliche Behandlungsanleitung inkl. Qualifikation, Spezialdokumentation Patientenkontakt. Exkl.: Dokumentation aus spezifischeren Dokumentenklassen - wie bspw. Entlassungsbericht, Konsilbericht, Aufnahmbefund, Anamnesebogen, Therapieplan, Verlaufsdokumentation, Visitenprotokoll, Teambesprechungsprotokoll, diagnostische/therapeutische (Fremd-)Leistungen"
            },
            {
              "code" : "SD160199",
              "display" : "Sonstiges psychiatrisch-psychotherapeutisches Dokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Psychischer Untersuchungsbefund, Psychopathologischer Befund"
            }
          ]
        }
      ]
    },
    {
      "code" : "SF",
      "display" : "Studien/Forschung",
      "concept" : [
        {
          "code" : "SF0601",
          "display" : "Forschungsdokumente",
          "concept" : [
            {
              "code" : "SF060101",
              "display" : "Forschungsbericht",
              "definition" : "Die Dokumentation beinhaltet Angaben zu allen Forschungsvorhaben in einem Zeitraum, die in einer Einrichtung durchgeführt wurden."
            },
            {
              "code" : "SF060199",
              "display" : "Sonstige Forschungsdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "SF1901",
          "display" : "Studiendokumente",
          "concept" : [
            {
              "code" : "SF190101",
              "display" : "CRF-Bogen",
              "definition" : "Die Dokumentation beinhaltet Erhebungen für Klinische Studien. Diese sind inhaltlich unterschiedlich und abhängig von der Fragestellung der durchzuführenden Studie."
            },
            {
              "code" : "SF190102",
              "display" : "Einwilligung Studie",
              "definition" : "Die Dokumentation beinhaltet die unterzeichnete Einwilligungserklärung zur Teilnahme an einer Studie."
            },
            {
              "code" : "SF190103",
              "display" : "Protokoll Ein- und Ausschlusskriterien",
              "definition" : "Die Dokumentation beinhaltet präzise Kriterien, die eine Teilnahme an einer Studie ermöglichen oder ausschließen."
            },
            {
              "code" : "SF190104",
              "display" : "Prüfplan",
              "definition" : "Die Dokumentation beinhaltet die Beschreibung und Festlegung der wichtigsten Merkmale des Forschungsvorhabens."
            },
            {
              "code" : "SF190105",
              "display" : "SOP-Bogen",
              "definition" : "Die Dokumentation beinhaltet Arbeitsanweisungen zur Sicherstellung einheitlicher Arbeitsabläufe im Rahmen des Forschungsvorhabens."
            },
            {
              "code" : "SF190106",
              "display" : "Studienbericht",
              "definition" : "Die Dokumentation beinhaltet die Veröffentlichung einer durchgeführten Studie."
            },
            {
              "code" : "SF190199",
              "display" : "Sonstige Studiendokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        }
      ]
    },
    {
      "code" : "TH",
      "display" : "Therapie",
      "concept" : [
        {
          "code" : "TH0201",
          "display" : "Bestrahlungstherapien",
          "concept" : [
            {
              "code" : "TH020101",
              "display" : "Bestrahlungsplan",
              "definition" : "Die Dokumentation beinhaltet die individuelle Planung einer Bestrahlungstherapie mit Angaben über Lokalisation, Zeitraum und Dosis."
            },
            {
              "code" : "TH020102",
              "display" : "Bestrahlungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über die Durchführung einer Bestrahlungstherapie und die Dosisleistung."
            },
            {
              "code" : "TH020103",
              "display" : "Bestrahlungsverordnung",
              "definition" : "Die Dokumentation beinhaltet die Anweisung einer Bestrahlungstherapie zur Behandlung."
            },
            {
              "code" : "TH020104",
              "display" : "Radiojodtherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet den Nachweis der nuklearmedizinischen Therapie zur Behandlung von Schilddrüsenerkrankungen. Inkl.: Radiojodtest Exkl.: Therapieprotokoll mit Radionukliden"
            },
            {
              "code" : "TH020105",
              "display" : "Therapieprotokoll mit Radionukliden",
              "definition" : "Die Dokumentation beinhaltet den Nachweis der nuklearmedizinischen Behandlung, bei der Patienten radioaktive Substanzen verabreicht bekommen. Exkl.: Radiojodtherapie"
            },
            {
              "code" : "TH020199",
              "display" : "Sonstiges Bestrahlungstherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Anmeldung zur Strahlentherapie, Verlaufsbericht Strahlentherapie"
            }
          ]
        },
        {
          "code" : "TH0601",
          "display" : "Funktionstherapien",
          "concept" : [
            {
              "code" : "TH060101",
              "display" : "Ergotherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Planung, Zielsetzung und Durchführung der ergotherapeutischen Behandlung. Inkl.: Abschlussbericht, Exkl.: Anforderung Funktionstherapie"
            },
            {
              "code" : "TH060102",
              "display" : "Logopädieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Planung, Zielsetzung und Durchführung der logopädischen Behandlung. Inkl.: Abschlussbericht, Exkl.: Anforderung Funktionstherapie"
            },
            {
              "code" : "TH060103",
              "display" : "Physiotherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Planung, Zielsetzung und Durchführung der physiotherapeutischen Behandlung. Inkl.: Abschlussbericht, Exkl.: Anforderung Funktionstherapie"
            },
            {
              "code" : "TH060104",
              "display" : "Anforderung Funktionstherapie",
              "definition" : "Die Dokumentation beinhaltet die Anforderung bzw. Anmeldung einer therapeutischen Behandlung."
            },
            {
              "code" : "TH060105",
              "display" : "Elektrokonvulsionstherapie",
              "definition" : "Die Dokumentation beinhaltet die fachärztliche Indikationsstellung, Durchführungs- und Überwachungsnachweise. Exkl.: Aufklärung (siehe Aufklärungsbogen Therapie)"
            },
            {
              "code" : "TH060106",
              "display" : "Transkranielle Magnetstimulation",
              "definition" : "Die Dokumentation beinhaltet die fachärztliche Indikationsstellung, Durchführungs- und Überwachungsnachweise. Exkl.: Aufklärung"
            },
            {
              "code" : "TH060199",
              "display" : "Sonstiges Funktionstherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Fototherapie, Hypothermiebogen, Reittherapie. Exkl.: Spezialtherapeutische Verlaufsdokumentation"
            }
          ]
        },
        {
          "code" : "TH1301",
          "display" : "Medikamentöse Therapien",
          "concept" : [
            {
              "code" : "TH130101",
              "display" : "Anforderung Medikation",
              "definition" : "Die Dokumentation beinhaltet die Anforderung von Arzneimitteln an eine dafür zuständige Ausgabestelle."
            },
            {
              "code" : "TH130102",
              "display" : "Arzneiadministration",
              "definition" : "Die Dokumentation beinhaltet Angaben zu einer Medikamentengabe (bspw. verabreichte Menge, Chargennummer, Applikationsweg, Verabreichungsdatum, Verabreichende/r, Empfänger/in). Inkl.: Auszüge aus einem Apothekenbuch, Chargendokumentation Apotheke"
            },
            {
              "code" : "TH130103",
              "display" : "Chemotherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über die verabreichte Dosis der Zytostatika und die Anzahl der Zyklen."
            },
            {
              "code" : "TH130104",
              "display" : "Hormontherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über die verabreichte Dosis der Hormone und die Anzahl der Zyklen."
            },
            {
              "code" : "TH130105",
              "display" : "Medikamentenplan extern",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "TH130106",
              "display" : "Medikamentenplan intern/extern (mit BTM)",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "TH130107",
              "display" : "Medikationsplan",
              "definition" : "Die Dokumentation beinhaltet eine Übersicht über verordnete Arzneimittel. Exkl.: Medikationsplan elektronisch (eMP) = bundeseinheitlicher Medikationsplan - ED110103"
            },
            {
              "code" : "TH130108",
              "display" : "Rezept",
              "definition" : "Die Dokumentation beinhaltet die Verschreibung des Arztes auf einem standardisiertem Formular von Arznei- oder Heilmitteln. Inkl. Muster 16 KBV, Sonderformen bspw. BTM. Exkl.: eRezept, Anforderung Medikation, Postoperative Verordnung"
            },
            {
              "code" : "TH130109",
              "display" : "Schmerztherapieprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Durchführung einer medikamentösen schmerzlindernden Therapie. Inkl.: Therapieplan Schmerztherapie"
            },
            {
              "code" : "TH130110",
              "display" : "Prämedikationsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Anordnung und Verabreichung von Medikamenten vor einer Maßnahme. Exkl.: Anästhesieaufklärungsbogen, Präoperative Anästhesiedokumentation"
            },
            {
              "code" : "TH130111",
              "display" : "Lyse Dokument",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Durchführung einer medikamentösen Therapie zur Lösung von Blutgerinnseln. Inkl.: Checkliste Lysetherapie Exkl.: Dialyse"
            },
            {
              "code" : "TH130199",
              "display" : "Sonstiges Dokument medikamentöser Therapie",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Lieferschein Medikation"
            }
          ]
        },
        {
          "code" : "TH1601",
          "display" : "Patientenschulungen",
          "concept" : [
            {
              "code" : "TH160101",
              "display" : "Protokoll Ernährungsberatung",
              "definition" : "Die Dokumentation beinhaltet Angaben zu empfohlenen Nahrungsmitteln aufgrund verschiedener Indikationen."
            },
            {
              "code" : "TH160102",
              "display" : "Apotheke Patientenberatung",
              "definition" : "Die Dokumentation beinhaltet Angaben eines Apotheker/Apothekerin zu empfohlenen Arzneimitteln aufgrund verschiedener Indikationen bzw. zur geeigneten Arzneimittelauswahl - auch mit Berücksichtigung einer Selbstmedikation. Exkl. Arzneimittelinformation"
            },
            {
              "code" : "TH160199",
              "display" : "Sonstiges Protokoll Patientenschulung",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Anmeldung Patientenschulung, Exkl.: Diabetesberatung"
            }
          ]
        },
        {
          "code" : "TH2001",
          "display" : "Transfusionsdokumente",
          "concept" : [
            {
              "code" : "TH200101",
              "display" : "Anforderung Blutkonserven",
              "definition" : "Die Dokumentation beinhaltet die Anforderung von benötigten Blutkonserven bei einer Blutbank."
            },
            {
              "code" : "TH200102",
              "display" : "Blutspendeprotokoll",
              "definition" : "Die Dokumentation beinhaltet alle relevanten Angaben zur Durchführung der Blutabgabe und des Spenders."
            },
            {
              "code" : "TH200103",
              "display" : "Bluttransfusionsprotokoll",
              "definition" : "Die Dokumentation beinhaltet alle relevanten Angaben zur Übertragung von Blut oder Blutbestandteilen an den Empfänger."
            },
            {
              "code" : "TH200104",
              "display" : "Konservenbegleitschein",
              "definition" : "Die Dokumentation beinhaltet alle relevanten Daten zu einer angeforderten Blutkonserve."
            },
            {
              "code" : "TH200199",
              "display" : "Sonstiges Transfusionsdokument",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Checkliste Transfusion, Konservenausgabeprotokoll"
            }
          ]
        },
        {
          "code" : "TH2301",
          "display" : "Weitere Therapiedokumente",
          "concept" : [
            {
              "code" : "TH230199",
              "display" : "Sonstige Therapiedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL der Unterklassen TH0201, TH0601, TH1301, TH1601, TH2001 abgebildet werden kann."
            }
          ]
        }
      ]
    },
    {
      "code" : "VL",
      "display" : "Verlauf",
      "concept" : [
        {
          "code" : "VL0101",
          "display" : "Assessmentbögen",
          "concept" : [
            {
              "code" : "VL010101",
              "display" : "Dekubitusrisikoeinschätzung",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Einschätzung des Risikos ein Druckgeschwür zu entwickeln."
            },
            {
              "code" : "VL010102",
              "display" : "Mini Mental Status Test inkl. Uhrentest",
              "definition" : "Die Dokumentation beinhaltet Testaufgaben zur Feststellung von Defiziten der Wahrnehmung, des Denkens sowie der kognitiven Fähigkeiten. Die Auswertung erfolgt über ein Punktesystem."
            },
            {
              "code" : "VL010103",
              "display" : "Schmerzerhebungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zu Lokalisation, Stärke sowie Ursache von Schmerzen."
            },
            {
              "code" : "VL010104",
              "display" : "Ernährungsscreening",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Einschätzung des Ernährungszustands."
            },
            {
              "code" : "VL010105",
              "display" : "Aphasiescreening",
              "definition" : "Die Dokumentation beinhaltet Testaufgaben, für Erwachsene und Jugendliche ab dem 14. Lebensjahr, zur Diagnose und zum Verlauf einer erworbenen Sprachstörung bzw. zentralen Schädigung des Gehirns."
            },
            {
              "code" : "VL010106",
              "display" : "Glasgow Coma Scale",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Einschätzung einer Bewusstseins- und Hirnfunktionsstörung bei Erwachsenen nach Schädel-Hirn-Trauma."
            },
            {
              "code" : "VL010107",
              "display" : "NIH Stroke Scale",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Beurteilung eines akut aufgetretenen Schlaganfalls. Die Auswertung erfolgt mittels Punktesystem."
            },
            {
              "code" : "VL010108",
              "display" : "IPSS (Internationaler Prostata Symptom Score)",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Einschätzung des Harnverhalts. Die Auswertung erfolgt mittels Punktesystem."
            },
            {
              "code" : "VL010199",
              "display" : "Sonstiger Assessmentbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Atemskala, COPD Assessment, Delirium Screening, Finnegan Score, Hornheider Screening Instrument, Karnofsky Index, Wortfindungstest, Schreibprobe, Dubowitz Score"
            }
          ]
        },
        {
          "code" : "VL0102",
          "display" : "Apothekendokumentation",
          "concept" : [
            {
              "code" : "VL010201",
              "display" : "Apotheke Entlassbericht",
              "definition" : "Die Dokumentation beinhaltet Hinweise eines Apothekers/Apothekerin zur Arzneimitteltherapie während der Behandlung. Dazu zählen Warn- und Anwendungshinweise, Monitoringempfehlungen. Hinweis: Sind die Hinweise Bestandteil des ärztlichen Entlassungsberichtes ist die KDL AD010115 (Entlassungsbericht) zu verwenden."
            },
            {
              "code" : "VL010202",
              "display" : "Apotheke Betreuungsplan",
              "definition" : "Die Dokumentation beinhaltet Angaben zum chronologischen Verlauf Arzneimittel bedingter Probleme (ABP) und das Ergebnis durchgeführter Maßnahmen aus Sicht des Apothekers/Apothekerin."
            },
            {
              "code" : "VL010203",
              "display" : "Arzneimittelinformation",
              "definition" : "Die Dokumentation beinhaltet eine Aufklärung, Anweisung oder Information zu Arzneimitteln insbesondere zur Anwendung bestehender Medikation. Exkl. Belehrung, Informationsblatt"
            },
            {
              "code" : "VL010204",
              "display" : "Apotheke Validierung",
              "definition" : "Die Dokumentation beinhaltet die Freigabe von Verordnungen durch einen Apotheker/Apothekerin."
            },
            {
              "code" : "VL010205",
              "display" : "Apotheke Visitenprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zu pharmazeutischen Visiten mit Besprechung des aktuellen Zustandes sowie weiterer Maßnahmen bzgl. der Arzneimitteltherapie. Exkl. Visitenprotokoll"
            },
            {
              "code" : "VL010206",
              "display" : "AMTS-Prüfbericht",
              "definition" : "Die Dokumentation beinhaltet die Einschätzung und Empfehlung eines (Fach-)Apothekers/Apothekerin zur Verbesserung der Arzneimitteltherapiesicherheit (AMTS)."
            },
            {
              "code" : "VL010207",
              "display" : "Apotheke Interventionsbericht",
              "definition" : "Die Dokumentation beinhaltet nicht-regelhafte pharmazeutische Interventionen bzw. pharmazeutische Dienstleistungen - bspw. Drug-Monitoring-Protokoll, Sonderanforderungen (Import, Lieferengpass, patientenindividuelle Arzneimittelherstellungen)"
            },
            {
              "code" : "VL010208",
              "display" : "Arzneimittelabgabe",
              "definition" : "Die Dokumentation beinhaltet Angaben über die an Patient*innen von der Apotheke abgegebenen Arzneimittel."
            },
            {
              "code" : "VL010299",
              "display" : "Sonstige Apothekendokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "VL0401",
          "display" : "Diabetesdokumente",
          "concept" : [
            {
              "code" : "VL040101",
              "display" : "Diabetiker Kurve",
              "definition" : "Die Dokumentation beinhaltet Messungen zur Kontrolle des Blutzuckers über einen bestimmten Zeitraum."
            },
            {
              "code" : "VL040102",
              "display" : "Insulinplan",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Verabreichungsdauer und Verabreichungsart von Insulin."
            },
            {
              "code" : "VL040199",
              "display" : "Sonstige Diabetesdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Diabetes Verlaufsdokumentation, Diabetologische Empfehlungen, Diabetesberatung"
            }
          ]
        },
        {
          "code" : "VL0402",
          "display" : "Dialysedokumente",
          "concept" : [
            {
              "code" : "VL040201",
              "display" : "Dialyseanforderung",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Anmeldung oder Anforderung eines Blutreinigungsverfahrens."
            },
            {
              "code" : "VL040202",
              "display" : "Dialyseprotokoll",
              "definition" : "Die Dokumentation beinhaltet die Durchführung eines Blutreinigungsverfahrens."
            },
            {
              "code" : "VL040299",
              "display" : "Sonstige Dialysedokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Dialysebegleitschreiben, Dialysevisite"
            }
          ]
        },
        {
          "code" : "VL0403",
          "display" : "Durchführungsnachweise",
          "concept" : [
            {
              "code" : "VL040301",
              "display" : "Ein- und Ausfuhrprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zu Ein - und Ausfuhrmengen in einem bestimmten Zeitraum. Exkl.: Medikamentenplan, Sondenplan"
            },
            {
              "code" : "VL040302",
              "display" : "Fixierungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer einer freiheitsentziehenden Maßnahme. Inkl.: Fixierungsanordnung Exkl.: Antrag auf Fixierung"
            },
            {
              "code" : "VL040303",
              "display" : "Isolierungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer der Isolierungsmaßnahmen während der Behandlung."
            },
            {
              "code" : "VL040304",
              "display" : "Lagerungsplan",
              "definition" : "Die Dokumentation beinhaltet Angaben über festgelegte Lagerungsintervalle. Inkl.: Dekubitusprophylaxe, Bewegungsplan"
            },
            {
              "code" : "VL040305",
              "display" : "Punktionsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zum Verlauf einer Punktion sowie Nachweise von Biopsien und Checklisten. Inkl.: diagnostischer oder therapeutischer Punktion, Anmeldung zur Punktion"
            },
            {
              "code" : "VL040306",
              "display" : "Punktionsprotokoll therapeutisch",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "VL040307",
              "display" : "Reanimationsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer der durchgeführten Wiederbelebungsmaßnahme."
            },
            {
              "code" : "VL040308",
              "display" : "Sondenplan",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer der zu verabreichenden Sondennahrung."
            },
            {
              "code" : "VL040309",
              "display" : "Behandlungsplan",
              "definition" : "Die Dokumentation beinhaltet eine Übersicht von geplanten Maßnahmen zur Behandlung. Inkl.: KBV Muster 70 (Behandlungsplan für Maßnahmen zur künstlichen Befruchtung), Terminplan, Übersicht über Behandlungstermine"
            },
            {
              "code" : "VL040310",
              "display" : "Infektionsdokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer der Behandlung von Infektionskrankheiten und Erregern. Inkl.: MRSA/MRE Screening und Sanierung Exkl.: Nosokomialdokumentation"
            },
            {
              "code" : "VL040311",
              "display" : "Nosokomialdokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Art und Dauer der Behandlung von im Krankenhaus erworbenen Infektionskrankheiten und Erregern. Inkl.: Screening auf nosokomiale Infektion Exkl.: Infektionsdokumentationsbogen"
            },
            {
              "code" : "VL040312",
              "display" : "Stomadokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben zur Erst-und Folgeversorgung eines künstlichen Ausganges."
            },
            {
              "code" : "VL040313",
              "display" : "Katheterdokument",
              "definition" : "Die Dokumentation beinhaltet Angaben über die Sondierung, Entleerung oder Spülung eines Hohlorgans. Weitere Inhalte können auch die Anlage oder Entfernung eines Venenkatheters sein. Exkl.: Katheterdokumentation zur Schmerztherapie, Dialyse, Herzkatheter"
            },
            {
              "code" : "VL040314",
              "display" : "Kardioversion",
              "definition" : "Die Dokumentation beinhaltet eine kurze Zusammenfassung des Procedere, welches elektronisch oder medikamentös durchgeführt werden kann. Dokumentiert wird in Freitext oder auf standardisiertem Formular. Weitere Inhalte können Angaben zu den Vitaldaten und zur Sedierung während der Durchführung sein."
            },
            {
              "code" : "VL040399",
              "display" : "Sonstiger Durchführungsnachweis",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Blasenspülprotokoll, Inhalationsplan"
            }
          ]
        },
        {
          "code" : "VL0901",
          "display" : "Intensivmedizinische Dokumente",
          "concept" : [
            {
              "code" : "VL090101",
              "display" : "Beatmungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet standardisierte Angaben zur Art und Dauer von Beatmungsepisoden."
            },
            {
              "code" : "VL090102",
              "display" : "Intensivkurve",
              "definition" : "Die Dokumentation beinhaltet Angaben über einen Zeitraum von 24 Stunden während einer intensivmedizinischen Versorgung. Vitalzeichen werden als Kurve dargestellt. Weitere Inhalte sind unter anderem: Medikamentenverabreichung, Pflegemaßnahmen, Beatmungssituation und Laborwerte. Inkl.: IMC Kurve Exkl.: Pflegekurve, Säuglingskurve"
            },
            {
              "code" : "VL090103",
              "display" : "Intensivpflegebericht",
              "definition" : "Die Dokumentation beinhaltet Angaben des Allgemeinzustands und der durchgeführten Maßnahmen während der intensivmedizinischen Versorgung. Die Erfassung erfolgt nicht standardisiert als Freitext. Exkl.: Pflegebericht"
            },
            {
              "code" : "VL090104",
              "display" : "Monitoringausdruck",
              "definition" : "Die Dokumentation beinhaltet Aufzeichnungen von Vitalzeichen und der Sauerstoffsättigung. Der Ausdruck wird elektronisch über einen Vitaldatenmonitor erstellt. Exkl.: Überwachungsprotokoll"
            },
            {
              "code" : "VL090105",
              "display" : "Intensivdokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zur standardisierten Erfassung unter anderem von: Vitalzeichen, Medikamentenverabreichung, Pflegemaßnahmen, Beatmungssituation und Laborwerten."
            },
            {
              "code" : "VL090199",
              "display" : "Sonstiger Intensivdokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Dokumentation Therapiebegrenzung, Hämodynamische Verlaufsdokumentation, PICCO Protokoll."
            }
          ]
        },
        {
          "code" : "VL1601",
          "display" : "Pflegedokumente",
          "concept" : [
            {
              "code" : "VL160101",
              "display" : "Auszug aus den medizinischen Daten",
              "definition" : "Die Dokumentation beinhaltet Angaben über Diagnostik, Krankheits- und den Behandlungsverlauf eines ausgewählten Zeitraumes, chronologisch erfasst."
            },
            {
              "code" : "VL160102",
              "display" : "Ernährungsplan",
              "definition" : "Die Dokumentation beinhaltet die Verordnung zur geplanten Ernährung."
            },
            {
              "code" : "VL160103",
              "display" : "Meldebogen Krebsregister",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "VL160104",
              "display" : "Pflegeanamnesebogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zum aktuellen Pflegezustand bei Aufnahme."
            },
            {
              "code" : "VL160105",
              "display" : "Pflegebericht",
              "definition" : "Die Dokumentation beinhaltet eine freitextliche Berichterstattung zum pflegerischen Zustand während eines bestimmten Behandlungszeitraums."
            },
            {
              "code" : "VL160106",
              "display" : "Pflegekurve",
              "definition" : "Die Dokumentation beinhaltet Angaben, über mehrere klinische Tage, zur Erfassung von Vitalzeichen, Medikamentengaben, Pflegemaßnahmen und Laborwerten. Vitalzeichen werden als Kurve dargestellt. Exkl.: Intensivkurve. Säuglingskurve"
            },
            {
              "code" : "VL160107",
              "display" : "Pflegeplanung",
              "definition" : "Die Dokumentation beinhaltet einen Maßnahmenplan, der die strukturierte und zielgerichtete Vorgehensweise von  Pflegekräften bei der Versorgung beschreibt."
            },
            {
              "code" : "VL160108",
              "display" : "Pflegeüberleitungsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zu sämtlichen pflegerelevanten Daten in Abhängigkeit von den Defiziten und Ressourcen. Sie dienen als Grundlage für die  weiterbehandelnde Einrichtung."
            },
            {
              "code" : "VL160109",
              "display" : "Sturzprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zu einem Sturz und den daraus resultierenden Maßnahmen."
            },
            {
              "code" : "VL160110",
              "display" : "Überwachungsprotokoll",
              "definition" : "Die Dokumentation beinhaltet Angaben zur engmaschigen, pflegerischen Überwachung über einen bestimmten Zeitraum. Exkl.: Monitoringausdruck"
            },
            {
              "code" : "VL160111",
              "display" : "Verlaufsdokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zum chronologischen Verlauf des Gesundheitszustandes und der durchgeführten Maßnahmen."
            },
            {
              "code" : "VL160112",
              "display" : "Pflegevisite",
              "definition" : "Die Dokumentation beinhaltet die Erfassung von Änderungen im Pflegeprozess und den daraus resultierenden Maßnahmen."
            },
            {
              "code" : "VL160113",
              "display" : "Fallbesprechung Bezugspflegekraft",
              "definition" : "Die Dokumentation beinhaltet Angaben zum aktuellen Pflegezustand und Planung von weiteren Maßnahmen."
            },
            {
              "code" : "VL160114",
              "display" : "Pflegenachweis",
              "definition" : "Die Dokumentation beinhaltet einen Nachweis von pflegerischen Leistungen. Exkl.: Pflegebericht"
            },
            {
              "code" : "VL160115",
              "display" : "Fotodokumentation Dekubitus",
              "definition" : "Die Dokumentation beinhaltet fotografierte Dekubiti. Exkl.: Fotodokumentation Dermatologie, Fotodokumentation Wunden, OP-Bilddokumentation"
            },
            {
              "code" : "VL160199",
              "display" : "Sonstiger Pflegedokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "VL2301",
          "display" : "Wunddokumente",
          "concept" : [
            {
              "code" : "VL230101",
              "display" : "Wunddokumentationsbogen",
              "definition" : "Die Dokumentation beinhaltet Angaben zu Hautdefekten, deren Lokalisation, Versorgung und Beschreibung. Inkl.: Wundkonsil"
            },
            {
              "code" : "VL230102",
              "display" : "Bewegungs- und Lagerungsplan",
              "definition" : "n.a.",
              "property" : [
                {
                  "code" : "status",
                  "valueCode" : "deprecated"
                }
              ]
            },
            {
              "code" : "VL230103",
              "display" : "Fotodokumentation Wunden",
              "definition" : "Die Dokumentation beinhaltet bspw. postoperativ fotografierte Hautdefekte, Brandwunden, mechanische Wunden. Hier sind nur gedruckte Fotografien zu klassifizieren. Exkl.: Fotodokumentation Dermatologie, Fotodokumentation Dekubitus, OP-Bilddokumentation"
            },
            {
              "code" : "VL230199",
              "display" : "Sonstige Wunddokumentation",
              "definition" : "Die Dokumentation beinhaltet Angaben, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann. Inkl.: Anamnese Wunddokumentation, Aufnahme- und Kurzprotokoll Wundtherapie, Wundmanagement"
            }
          ]
        }
      ]
    },
    {
      "code" : "UB",
      "display" : "Sonstiges",
      "concept" : [
        {
          "code" : "UB1401",
          "display" : "Nachweisdokumentation: Infrastruktur",
          "concept" : [
            {
              "code" : "UB140101",
              "display" : "Behördliche Genehmigung",
              "definition" : "Die Dokumentation beinhaltet Bescheinigungen einer Behörde für die Erbringung von Leistungen in der Gesundheitsversorgung - bspw. HybridOP, Hubschrauberlandeplatz, Telemedizin, Versorgungsauftrag, landesspezfische Regelungen. Inkl. Zulassung, Feststellungsbescheid (Krankenhausplan)"
            },
            {
              "code" : "UB140102",
              "display" : "Dokumentation vorhandender Infrastruktur",
              "definition" : "Die Dokumentation beinhaltet den Nachweis vorhandener Räumlichkeiten, Geräte, bauliche Einrichtungen oder anderer Infrastruktur - bspw. Fotografie, Video, Luftfilter, Lüftungsanlage, Grundriss, Lageplan, Bauplan, Bauzeichnung, Raumplan"
            },
            {
              "code" : "UB140199",
              "display" : "Sonstiger Nachweis Infrastruktur",
              "definition" : "Die Dokumentation beinhaltet Nachweise zur vorhandenen Infrastruktur, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "UB1402",
          "display" : "Nachweisdokumentation: Personal",
          "concept" : [
            {
              "code" : "UB140201",
              "display" : "Berufserlaubnis",
              "definition" : "Die Dokumentation beinhaltet den Nachweis, dass der erlernte Beruf ausgeübt werden darf. Bei nicht akademischen Gesundheitsfachberufen ist die Erlaubnisurkunde - sofern landesspezifische erforderlich - bei der zuständigen Stelle anzufordern. Inkl. Nachweis der Berufsbezeichnung, vorläufige (ärztliche) Berufserlaubnis, Belegarztzulassung der KV"
            },
            {
              "code" : "UB140202",
              "display" : "Approbation",
              "definition" : "Die Dokumentation umfasst die staatliche Zulassung den ärztlichen Beruf selbstständig und eigenverantwortlich auszuüben."
            },
            {
              "code" : "UB140203",
              "display" : "Arbeitsvertrag",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über das Anstellungsverhältnis, unabhängig ob direkt angestellt oder von Dritten überlassen. Inkl. Anstellungsvertrag, Weiterbildungsvertrag, Arbeitnehmerüberlassung, Zeitarbeitsvertrag, Änderungsvertrag"
            },
            {
              "code" : "UB140204",
              "display" : "Arbeitszeugnis",
              "definition" : "Die Dokumentation beinhaltet den Nachweis des Arbeitgebers der Auskunft über Dauer, Position, Art des Arbeitsverhältnisses, Informationen zum Verhalten sowie eine Bewertung der erbrachten Leistungen. Inkl. Zwischenzeugnis, Erfahrungsnachweis"
            },
            {
              "code" : "UB140205",
              "display" : "Dienstleistungsvereinbarung",
              "definition" : "Die Dokumentation beinhaltet den Nachweis von vereinbarten Leistungen, die (gegenseitig) erbracht werden. Sie ist Grundlage für die Zusammenarbeit. Inkl. Belegarztvertrag, Kooperationsvereinbarung, Vertrag mit Netzwerken oder der KV (bspw. Notfallstufen)"
            },
            {
              "code" : "UB140206",
              "display" : "Dienstplan",
              "definition" : "Die Dokumentation beinhaltet die Personaleinsatzplanung. Inkl. SOLL-Dienstplan, IST-Dienstplan"
            },
            {
              "code" : "UB140207",
              "display" : "Weiterbildungs-/Fortbildungs-/Qualifikationsnachweis",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über die Teilnahme an einer Veranstaltung, Fort- oder Weiterbildung. Inkl. Teilnahmebescheinigung, Zeugnis, Urkunde, Facharztqualifikation, Fachkundenachweis, Urkunde über Schwerpunktbezeichnung/Zusatzbezeichnung"
            },
            {
              "code" : "UB140208",
              "display" : "Ausbildungsbefugnis",
              "definition" : "Die Dokumentation beinhaltet den Nachweis, dass Personal berechtigt ist, in einem bestimmten Bereich die Ausbildung anzuleiten und zu überwachen. Inkl. Weiterbildungsbefugnis der Ärztekammer, Ausbildungsbefugnis von IHK, HWK"
            },
            {
              "code" : "UB140209",
              "display" : "Personalliste",
              "definition" : "Die Dokumentation beinhaltet einen Auszug aus dem Personalmanagementsystem mit der Benennung von Personal und deren Zuständigkeiten."
            },
            {
              "code" : "UB140210",
              "display" : "Auszug aus der Personalakte",
              "definition" : "Die Dokumentation beinhaltet Auszüge aus der Personalverlaufsdokumentation - bspw. Namensänderung."
            },
            {
              "code" : "UB140211",
              "display" : "PuPGV-Nachweis",
              "definition" : "Die Dokumentation beinhaltet den Nachweis für die Einhaltung der Personaluntergrenzen gem. §137i Abs. 4 SGB V."
            },
            {
              "code" : "UB140299",
              "display" : "Sonstiger Nachweis Personal",
              "definition" : "Die Dokumentation beinhaltet Nachweise zum Personal, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "UB1403",
          "display" : "Nachweisdokumentation: Sachliche Ausstattung",
          "concept" : [
            {
              "code" : "UB140301",
              "display" : "Arzneimittelliste",
              "definition" : "Die Dokumentation beinhaltet den Nachweis von Arzneimittelbeständen oder Blutprodukten."
            },
            {
              "code" : "UB140302",
              "display" : "Inventarliste",
              "definition" : "Die Dokumentation beinhaltet den Nachweis von vorhandenem Material und Geräten. Inkl. Ausstattungsaufstellung"
            },
            {
              "code" : "UB140303",
              "display" : "Medizinproduktebuch",
              "definition" : "Die Dokumentation beinhaltet die zusammenfassende Dokumentation aller Daten eines betriebenen Medizinproduktes. Die erforderlichen Daten sind §12 MPBetreibV zu entnehmen."
            },
            {
              "code" : "UB140304",
              "display" : "Geräteeinweisung",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über durchgeführte Einweisungen von Personal an medizinischen Geräten. "
            },
            {
              "code" : "UB140399",
              "display" : "Sonstiger Nachweis sachliche Ausstattung",
              "definition" : "Die Dokumentation beinhaltet Nachweise zur Ausstattung, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "UB1404",
          "display" : "Nachweisdokumentation: Prozesse",
          "concept" : [
            {
              "code" : "UB140401",
              "display" : "Aufstellung erbrachte Leistungen",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über erbrachten Eingriffe gem. Anlage 1 bei QK - QSFFx oder über Erfahrung - Fallzahlen/Mindestmengen bei QK - CAR-t."
            },
            {
              "code" : "UB140402",
              "display" : "Aufstellung medizinische Angebote",
              "definition" : "Die Dokumentation beinhaltet den Nachweis über medizinische Angebote - wie bspw. Schmerztherapie, Strahlentherapie, Nuklearmedizin, Infektiologie, Polytrauma. Inkl. Behandlungsnachweise"
            },
            {
              "code" : "UB140403",
              "display" : "Dokumentation Behandlungsprogramm",
              "definition" : "Die Dokumentation beinhaltet Informationen zum Behandlungskonzept für definierte medizinische Leistungen - bspw. 8-98b.3, 8-985, 9-694, QK - Transplantationsprogramme (Stammzelltransplantation), QK - Zolgensma (§3 Abs 3), QK - Notfall - Modul Herz - Nachweis perkutane Schrittmachertherapie."
            },
            {
              "code" : "UB140404",
              "display" : "Fallliste",
              "definition" : "Die Dokumentation beinhaltet die Aufstellung von behandelten Patient*innen, die als Grundlage für eine Stichprobenprüfung dienen."
            },
            {
              "code" : "UB140405",
              "display" : "Hygieneplan",
              "definition" : "Die Dokumentation beinhaltet Verfahrensweisen zur Einhaltung von Hygiene-Standards."
            },
            {
              "code" : "UB140406",
              "display" : "Organigramm",
              "definition" : "Die Dokumentation beinhaltet die grafische Darstellung der Aufbauorganisation. Daran sind u.a. organisatorische Einheiten und Aufgabenverteilung nachvollziehbar."
            },
            {
              "code" : "UB140407",
              "display" : "Verfahrensanweisung",
              "definition" : "Die Dokumentation beinhaltet Vorgaben zur Durchführung von Prozessen und Informationen zu Prozessverantwortlichen. Inkl. Arbeitsanweisung, Standardarbeitsanweisung, SOP"
            },
            {
              "code" : "UB140408",
              "display" : "Dienstanweisung",
              "definition" : "Die Dokumentation beinhaltet Weisungen für die Arbeitnehmenden zur Durchführung konkreter Aufgaben. Inkl. Betriebsanweisung"
            },
            {
              "code" : "UB140409",
              "display" : "Zertifizierungsurkunde",
              "definition" : "Die Dokumentation beinhaltet den Nachweis für das Vorhandensein einer spezifischen Kompetenz. Inkl. Akkreditierungsurkunde"
            },
            {
              "code" : "UB140499",
              "display" : "Sonstiger Nachweis Prozesse",
              "definition" : "Die Dokumentation beinhaltet Nachweise zu Verfahren und Abläufen, die nicht in einer spezifischeren KDL dieser Unterklasse abgebildet werden kann."
            }
          ]
        },
        {
          "code" : "UB9999",
          "display" : "Sonstige Dokumentation",
          "concept" : [
            {
              "code" : "UB999996",
              "display" : "Nachweise (Zusatz-) Entgelte",
              "definition" : "Die Dokumentation beinhaltet die Nachweise (inkl. Dosis, Mengenangaben, Indikationsstellung) der durchgeführten diagnostischen, therapeutischen und/oder pflegerischen Maßnahmen von Entgelten, ergänzenden Tagesentgelten (ET), ZE oder ZP. Dieser KDL-Kode ist ausschließlich für die Anforderung von Unterlagen durch den MD zu verwenden. "
            },
            {
              "code" : "UB999997",
              "display" : "Gesamtdokumentation stationäre Versorgung",
              "definition" : "Die Dokumentation beinhaltet eine Sammlung verschiedener Dokumententypen im Rahmen der stationären Versorgung. Diese KDL ist nur in Einzelfällen zu verwenden. Beispiel: elektronischer Austausch der gesamten Patientenakte"
            },
            {
              "code" : "UB999998",
              "display" : "Gesamtdokumentation ambulante Versorgung",
              "definition" : "Die Dokumentation beinhaltet eine Sammlung verschiedener Dokumententypen im Rahmen der ambulanten Versorgung. Diese KDL ist nur in Einzelfällen zu verwenden. Beispiel: elektronischer Austausch der gesamten Ambulanzakte"
            },
            {
              "code" : "UB999999",
              "display" : "Sonstige medizinische Dokumentation",
              "definition" : "Die Dokumentation beinhaltet alle Dokumententypen, die nicht in eine spezifischeren KDL aller Unterklassen abgebildet werden können. Inkl.: Patientenetiketten, Visitenkarte, Registerblätter"
            }
          ]
        }
      ]
    }
  ]
}

```
