# Home - v2025.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://dvmd.de/fhir/ImplementationGuide/dvmd.kdl.r4 | *Version*:2025.0.1 |
| Active as of 2025-11-24 | *Computable Name*:KDL |

# KDL

Feel free to modify this index page with your own awesome content!

