# dvmd.kdl.r4#2026.0.0: Klinische Dokumentenklassen-Liste (KDL)

## Pages

* [Home](index.md)
* [Aenderungen Zur Vorversion](Aenderungen-zur-Vorversion.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [CodeSystem Klinische Dokumentenklassen-Liste 2026](CodeSystem-kdl.md)

### ValueSets

* [Klinische Dokumentenklassen-Liste 2026](ValueSet-kdl-all.md)
* [Dokumenten(typ)klassen Klinische Dokumentenklassen-Liste 2026](ValueSet-kdl.md)

### ConceptMaps

* [ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.classCodes - Kontext: Archivierung, inkl. eVV](ConceptMap-kdl-ihe-classcode.md)
* [ConceptMap zur Übersetzung von KDL-Codes in IHE-XDS DocumentEntry.typeCodes - Kontext: Archivierung, inkl. eVV](ConceptMap-kdl-ihe-typecode.md)

### ImplementationGuides

* [Klinische Dokumentenklassen-Liste (KDL)](index.md)

### Examples

* [kdl-dokref-ex-1 (DocumentReference)](DocumentReference-kdl-dokref-ex-1.md)
* [kdl-dokref-ex-2 (DocumentReference)](DocumentReference-kdl-dokref-ex-2.md)
